insert into product(product_id, precio, descripcion)
       values(000, 15,'pantalla 13x19');

insert into product(product_id, precio, descripcion)
       values(10, 5,'mouse windows 3500');
insert into product(product_id, precio, descripcion)
       values(1, 10,'teclado rosas latino');
insert into product(product_id, precio, descripcion)
       values(2, 48,'tarjeta red wifi ert-4565r');
insert into product(product_id, precio, descripcion)
       values(3, 30,'ram i45-dfg53-3 8GB');
insert into product(product_id, precio, descripcion)
       values(4, 100,'case rj-700 FOX');
insert into product(product_id, precio, descripcion)
       values(5, 30,'conector toshiba serie400-600');
insert into product(product_id, precio, descripcion)
       values(6, 45,'flex rd0-rr toshiba satelite');
insert into product(product_id, precio, descripcion)
       values(7, 35,'unidad cd fgh-78');
insert into product(product_id, precio, descripcion)
       values(8, 25,'bateria toshiba serie 500');
insert into product(product_id, precio, descripcion)
       values(9, 65,'ventilador externo');
       
select * from product;
