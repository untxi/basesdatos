SELECT count(*)department_name
FROM DEPARTMENT;

SELECT * FROM EMPLOYEE;
