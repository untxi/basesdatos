INSERT INTO employee(EMPLOYEE_ID, First_Name, last_name,email,phone_number,hire_date,salary,department_id,birthday)
VALUES(0000,'MARIELA','BARRANTES','MBARRANTES@GMAIL.COM',88889012, TO_DATE('25/08/2015','DD/MM/YYYY'),2500,0000,TO_DATE('04/01/1994','DD/MM/YYYY'));

INSERT INTO employee(EMPLOYEE_ID, First_Name, last_name,email,phone_number,hire_date,salary,department_id,birthday)
VALUES(0001,'SAMANTHA','ARBUROLA','SARBUROLA@GMAIL.COM',88889013, TO_DATE('25/08/2015','DD/MM/YYYY'),2500,0000,TO_DATE('04/01/1994','DD/MM/YYYY'));

INSERT INTO employee(EMPLOYEE_ID, First_Name, last_name,email,phone_number,hire_date,salary,department_id,birthday)
VALUES(0002,'ANA','RUIZ','ARUIZ@GMAIL.COM',88889014, TO_DATE('25/08/2015','DD/MM/YYYY'),1700,0002,TO_DATE('04/01/1994','DD/MM/YYYY'));

INSERT INTO employee(EMPLOYEE_ID, First_Name, last_name,email,phone_number,hire_date,salary,department_id,birthday)
VALUES(0003,'JORGE','FONSECA','JFONSECA@GMAIL.COM',88889015, TO_DATE('25/08/2015','DD/MM/YYYY'),1650,0002,TO_DATE('05/02/1994','DD/MM/YYYY'));

INSERT INTO employee(EMPLOYEE_ID, First_Name, last_name,email,phone_number,hire_date,salary,department_id,birthday)
VALUES(0004,'LUIS','MENDEZ','LMNDEZ@GMAIL.COM',88889016, TO_DATE('25/08/2015','DD/MM/YYYY'),1650,0003,TO_DATE('06/03/1994','DD/MM/YYYY'));

INSERT INTO employee(EMPLOYEE_ID, First_Name, last_name,email,phone_number,hire_date,salary,department_id,birthday)
VALUES(0005,'JULIA','GONZALEZ','JGONZALEZ@GMAIL.COM',88889017, TO_DATE('25/08/2015','DD/MM/YYYY'),1700,0003,TO_DATE('07/04/1994','DD/MM/YYYY'));

INSERT INTO employee(EMPLOYEE_ID, First_Name, last_name,email,phone_number,hire_date,salary,department_id,birthday)
VALUES(0006,'ANDRES','CORDOBA','ACORDOBA@GMAIL.COM',88889018, TO_DATE('25/08/2015','DD/MM/YYYY'),1000,0004,TO_DATE('08/05/1994','DD/MM/YYYY'));

INSERT INTO employee(EMPLOYEE_ID, First_Name, last_name,email,phone_number,hire_date,salary,department_id,birthday)
VALUES(0007,'PRISCILLA','SOLIS','PSOLIS@GMAIL.COM',88889019, TO_DATE('25/08/2015','DD/MM/YYYY'),1650,0004,TO_DATE('09/06/1994','DD/MM/YYYY'));

INSERT INTO employee(EMPLOYEE_ID, First_Name, last_name,email,phone_number,hire_date,salary,department_id,birthday)
VALUES(0008,'ROY','URE�A','RURE�A@GMAIL.COM',88889020, TO_DATE('25/08/2015','DD/MM/YYYY'),2000,0001,TO_DATE('10/07/1994','DD/MM/YYYY'));

INSERT INTO employee(EMPLOYEE_ID, First_Name, last_name,email,phone_number,hire_date,salary,department_id,birthday)
VALUES(0009,'SANDRA','WILLIAMS','SWILLIAMS@GMAIL.COM',88889021, TO_DATE('25/08/2015','DD/MM/YYYY'),1600,0001,TO_DATE('11/08/1994','DD/MM/YYYY'));

INSERT INTO employee(EMPLOYEE_ID, First_Name, last_name,email,phone_number,hire_date,salary,department_id,birthday)
VALUES(0010,'BERNANDO','VILLALOBOS','BVILLALOBOS@GMAIL.COM',88889022, TO_DATE('25/08/2015','DD/MM/YYYY'),1700,0003,TO_DATE('16/11/1994','DD/MM/YYYY'));

INSERT INTO employee(EMPLOYEE_ID, First_Name, last_name,email,phone_number,hire_date,salary,department_id,birthday)
VALUES(0011,'BENEDICTO','VARGAS','BVARGAS@GMAIL.COM',88889023, TO_DATE('25/08/2015','DD/MM/YYYY'),1600,0002,TO_DATE('11/08/1994','DD/MM/YYYY'));


SELECT *
FROM EMPLOYEE;
