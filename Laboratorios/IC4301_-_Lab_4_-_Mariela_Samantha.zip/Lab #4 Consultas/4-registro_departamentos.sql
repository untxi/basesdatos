INSERT INTO department(department_id, department_name)--, manager_id, location_id, dn)
VALUES(0000,'FINANCIERO');

INSERT INTO department(department_id, department_name)--, manager_id, location_id, dn)
VALUES(0001, 'RRHH');

INSERT INTO department(department_id, department_name)--, manager_id, location_id, dn)
VALUES(0002, 'VENTAS');

INSERT INTO department(department_id, department_name)--, manager_id, location_id, dn)
VALUES(0003, 'MERCADEO');

INSERT INTO department(department_id, department_name)--, manager_id, location_id, dn)
VALUES(0004, 'GERENCIA');

SELECT *
FROM department;
