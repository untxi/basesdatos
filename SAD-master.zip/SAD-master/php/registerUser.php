<?
include("database.php");
$name = $_POST['nombre'];
$lastname = $_POST['apellidouno'];
$secondLastname = $_POST['apellidodos'];
$email = $_POST['correo'];
$genre = $_POST['genre'];
$birthday = $_POST['birthday'];
$username = $_POST['usuario'];
$password = $_POST['contrasenna'];
$reppassword = $_POST['contrasennaVerificada'];
$idPerson= -1;



if ($password != $reppassword) {
	echo "<script>window.alert('Las contraseñas deben coincidir.');parent.location.href = 'http://sadtec.esy.es/page_registration1.html';</script>";
}
else{
	$sql = "INSERT INTO person(name, lastname, secondlastname, email, genre, birthday) VALUES ('".$name."','".$lastname."','".$secondLastname."','".$email."','".$genre."','".$birthday."');";
	$result = $conn->query($sql);

	$sql = "SELECT MAX( person_id ) as person_id FROM person;";

	$result = $conn->query($sql);

	if ($result->num_rows > 0) {

	    while($row = $result->fetch_assoc()) {
	    	$idPerson=$row["person_id"];
	    }
	   	
	}

	$sql = "INSERT INTO users( username,password,person_id) VALUES ('".$username."','".$password."',".$idPerson.");";
	$result = $conn->query($sql);
	echo "<script>window.alert('Usuario registrado correctamente.');parent.location.href = 'http://sadtec.esy.es/page_login1.html';</script>";

}



?>