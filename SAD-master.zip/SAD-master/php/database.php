<?php
$servername ="localhost";
$username = "u108313398_root";
$password = "sad1234";
$dbname = "u108313398_saddb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
?>
