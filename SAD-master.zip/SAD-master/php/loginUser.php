<?php

include("database.php");
$email = $_POST['correo'];
$password = $_POST['contrasenna'];
$idPerson = 0;
$passwordBD = "";

	$sql = "SELECT person_id FROM person WHERE email = '".$email."';";

	$result = $conn->query($sql);

	if ($result->num_rows > 0) {

	    while($row = $result->fetch_assoc()) {
	    	$idPerson=$row["person_id"];
	    }
	    $sql = "SELECT password FROM users WHERE person_id = ".$idPerson.";";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) {
		    
		    while($row = $result->fetch_assoc()) {
		    	$passwordBD=$row["password"];
		    }
			if ($passwordBD == $password) {
				echo "<script>parent.location.href = 'http://sadtec.esy.es/index.php';</script>";
			}
			
			else{
			
			echo "<script>window.alert('Correo electrónico o contraseña incorrectos.');parent.location.href = 'http://sadtec.esy.es/page_login1.html';</script>";
			}
		   	
		}
	}

	else{
		
		echo "<script>window.alert('Correo electrónico o contraseña incorrectos.');parent.location.href = 'http://sadtec.esy.es/page_login1.html';</script>";
	}

?>