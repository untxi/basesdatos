<footer>
    <p>© 2017 Diseño de Software, Semestre I. &nbsp;&nbsp; Sistema de Administración de Documentos</p>
    <img src="assets/img/wix/pen.png" alt="">
</footer>
<script src="js/script.js"></script>