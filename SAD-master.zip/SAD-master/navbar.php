<header class="menu-container">
   <section>
      <div>
       <span class="col-4 logo"><img src="assets/img/logo.png" alt="SAD"></span>
       
       <span class="col-6 sadtitle">Sistema de Adminsitración de Documentos</span>
        </div>
        
       <div class="col-1 linklogin"><a href="javascript:alert('Su sesión ha finalizado');window.location.replace('page_login1.html');">LogOut <img src="assets/img/wix/arrow.png" alt="===>"></a></div>
    </section>
    <nav>
		<ul class="col-12 topnav"  id="myTopnav">
			<li id="index" class=""><a href="index.php">Inicio</a></li>
			<!--<li id="categorias" class=""><a href="categorias.php">Categorías</a></li>-->
			<li id="recientes" class=""><a href="recientes.php">Documentos</a></li>
			<li id="buscar" class=""><a href="buscar.php">Buscar</a></li>
			<li id="registrar" class=""><a href="registrar.php">Registrar</a></li>
			<li id="ayuda" class=""><a href="ayuda.php">Ayuda</a></li>
			<li class="icon">
                <a href="javascript:void(0);"  onclick="nav()">Menu</a>                
            </li>
            <!--<div class="buscar">
                <input type="text" name="buscar" placeholder="Buscar">
                <button>Go!</button>
            </div>-->
		</ul>
   
    </nav>
</header>