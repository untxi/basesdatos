<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="es"> <!--<![endif]-->
<head>
    <title>SAD 2017</title>

    <!-- Meta -->
	<meta charset="utf-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
	<meta name="description" content="">
	<meta name="author" content="">

	<!-- Favicon -->
	<link rel="shortcut icon" href="favicon.ico">

	<!-- Web Fonts -->
	<link rel='stylesheet' type='text/css' href='//fonts.googleapis.com/css?family=Open+Sans:400,300,600&amp;subset=cyrillic,latin'>
	<link href="https://fonts.googleapis.com/css?family=Signika+Negative" rel="stylesheet">

	<!-- CSS Global Compulsory -->
	<link rel="stylesheet" type="text/css" href="assets/css/wix_styel.css">
	<link rel="stylesheet" href="assets/plugins/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/css/style.css">
	<link rel="stylesheet" href="assets/css/wix_styel.css">

	

	<!-- JS -->
	<script src="assets/js/custom.js"></script>
</head>

<body>
    <!-- Header -->
    <?php
        include('navbar.php')
    ?>
    <!-- End Header -->
    
	<!-- Page -->
	
	<div class="verFiles">
       <table class="col-10" id="tablaResultados">
       </table>
    </div>
   <!-- End Page -->
    

    <!-- Footer -->
    <?php
        include('footer.php')
    ?>
    <!-- End Footer -->

	<!-- JS Global Compulsory -->
	<script type="text/javascript" src="assets/plugins/jquery/jquery.min.js"></script>
	<script type="text/javascript" src="assets/plugins/jquery/jquery-migrate.min.js"></script>
	<script type="text/javascript" src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
	<!-- JS Customization -->
	
	<!-- JS Page Level -->
	<script type="text/javascript" src="assets/js/app.js"></script>
	<script type="text/javascript" src="assets/js/plugins/owl-carousel.js"></script>
	<script type="text/javascript" src="assets/js/plugins/style-switcher.js"></script>
	<script type="text/javascript" src="assets/js/plugins/parallax-slider.js"></script>
	<script src="https://www.gstatic.com/firebasejs/3.9.0/firebase.js"></script>
	<script type="text/javascript" src="assets/js/moment.min.js"></script>
	<script type="text/javascript" src="assets/js/recientes.js"></script>
		<!--[if lt IE 9]>
			<script src="assets/plugins/respond.js"></script>
			<script src="assets/plugins/html5shiv.js"></script>
			<script src="assets/plugins/placeholder-IE-fixes.js"></script>
		<![endif]-->

	</body>
	</html>
