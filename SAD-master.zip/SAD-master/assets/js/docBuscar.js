jQuery(document).ready(function() {
	App.init();
	StyleSwitcher.initStyleSwitcher();
  Validation.initValidation();
  $("#buscar").addClass('active');
  $("#verResult").hide();
});

moment().locale('es')

// Initialize Firebase
var config = {
  apiKey: "AIzaSyB8-HyHdHDeMkEd4rV1Puy9hVvkqGasku4",
  authDomain: "sadtec-71e39.firebaseapp.com",
  databaseURL: "https://sadtec-71e39.firebaseio.com",
  projectId: "sadtec-71e39",
  storageBucket: "sadtec-71e39.appspot.com",
  messagingSenderId: "216969228312"
};
firebase.initializeApp(config);

//Por si quiere registrar una categoría
/*firebase.database().ref('Categorias/').push({
  categoria: "Automática"
});*/


function cargarCategorias(){
  $("#myCat")
      .find('option')
      .remove()
      .end()
      .append('<option value="0">Seleccione una Categoría</option>')
      .val("0")
  ;
  var query = firebase.database().ref("Categorias").orderByChild("categoria");
  query.once("value").then(function(snapshot) {
    snapshot.forEach(function(childSnapshot) {
        // key will be "ada" the first time and "alan" the second time
        var key = childSnapshot.key
        var categoria = childSnapshot.val().categoria
        if (categoria != "Automática"){
          html = '<option value="'+key+'">'+categoria+'</option>'
          $("#myCat").append(html);
        }
    });
  });
}

cargarCategorias();


var Validation = function () {

    return {
        
        //Validation
        initValidation: function () {
          $("#buscarForm").validate({                   
              // Rules for form validation
              rules:
              {
                fecha:
                {
                  date: true
                }
              },
                                  
              // Messages for form validation
              messages:
              {
                fecha:
                {
                  date: 'Por favor, ingrese una fecha válida.'
                }
              },   
              
              // Do not change code below
              errorPlacement: function(error, element)
              {
                  error.insertAfter(element.parent());
             
              },
              submitHandler: function(form)
              {
                $("#verResult").show();
                $("#tablaResultados").html("")
                $("#tablaResultados").append(
                  '<tr class="col-12 titleTable">\
                       <td class="col-4">Mes/Día/Año</td>\
                       <td class="col-4">Título</td>\
                       <td class="col-4">Categoría</td>\
                   </tr>'
                  )
                var query = firebase.database().ref("Documentos").orderByChild("nombre");
                query.once("value").then(function(snapshot) {
                  snapshot.forEach(function(childSnapshot) {
                      // key will be "ada" the first time and "alan" the second time
                      var key = childSnapshot.key;
                      var nombre = childSnapshot.val().nombre;
                      var categoria = childSnapshot.val().categoria;
                      var url = childSnapshot.val().url;
                      var fecha = moment(childSnapshot.fecha).format('L');
                      var tituloBuscado = $("#titulo").val();
                      var fechaBuscada = $("#fecha").val();
                      var valCatBuscada = $("#myCat").val();
                      var categoriaBuscada = $("#myCat").find(":selected").text();
                      if (tituloBuscado == "" && fechaBuscada == "" && valCatBuscada != "0"){
                        if (categoria == categoriaBuscada){
                          $("#tablaResultados").append(
                            '<tr class="col-12">\
                              <td class="date">'+fecha+'</td>\
                              <td class="file"><a target="_blank" href="'+url+'">'+nombre+'</a></td>\
                              <td class="file">'+categoria+'</a></td>\
                            </tr>'
                          )
                        }
                      } else if (tituloBuscado != "" && fechaBuscada == "" && valCatBuscada == "0"){
                        if (~nombre.indexOf(tituloBuscado)){
                          $("#tablaResultados").append(
                            '<tr class="col-12">\
                              <td class="date">'+fecha+'</td>\
                              <td class="file"><a target="_blank" href="'+url+'">'+nombre+'</a></td>\
                              <td class="file">'+categoria+'</a></td>\
                            </tr>'
                          )
                        }
                      } else if (tituloBuscado == "" && fechaBuscada != "" && valCatBuscada == "0"){
                        if (fecha == fechaBuscada){
                          $("#tablaResultados").append(
                            '<tr class="col-12">\
                              <td class="date">'+fecha+'</td>\
                              <td class="file"><a target="_blank" href="'+url+'">'+nombre+'</a></td>\
                              <td class="file">'+categoria+'</a></td>\
                            </tr>'
                          )
                        }
                      } else if (tituloBuscado != "" && fechaBuscada != "" && valCatBuscada == "0"){
                        if (fecha == fechaBuscada && ~nombre.indexOf(tituloBuscado)){
                          $("#tablaResultados").append(
                            '<tr class="col-12">\
                              <td class="date">'+fecha+'</td>\
                              <td class="file"><a target="_blank" href="'+url+'">'+nombre+'</a></td>\
                              <td class="file">'+categoria+'</a></td>\
                            </tr>'
                          )
                        }
                      } else if (tituloBuscado == "" && fechaBuscada != "" && valCatBuscada != "0"){
                        if (fecha == fechaBuscada && categoria == categoriaBuscada){
                          $("#tablaResultados").append(
                            '<tr class="col-12">\
                              <td class="date">'+fecha+'</td>\
                              <td class="file"><a target="_blank" href="'+url+'">'+nombre+'</a></td>\
                              <td class="file">'+categoria+'</a></td>\
                            </tr>'
                          )
                        }
                      } else if (tituloBuscado != "" && fechaBuscada == "" && valCatBuscada != "0"){
                        if (~nombre.indexOf(tituloBuscado) && categoria == categoriaBuscada){
                          $("#tablaResultados").append(
                            '<tr class="col-12">\
                              <td class="date">'+fecha+'</td>\
                              <td class="file"><a target="_blank" href="'+url+'">'+nombre+'</a></td>\
                              <td class="file">'+categoria+'</a></td>\
                            </tr>'
                          )
                        }
                      } else if (tituloBuscado != "" && fechaBuscada != "" && valCatBuscada != "0"){
                        if (~nombre.indexOf(tituloBuscado) && categoria == categoriaBuscada && fecha == fechaBuscada){
                          $("#tablaResultados").append(
                            '<tr class="col-12">\
                              <td class="date">'+fecha+'</td>\
                              <td class="file"><a target="_blank" href="'+url+'">'+nombre+'</a></td>\
                              <td class="file">'+categoria+'</a></td>\
                            </tr>'
                          )
                        }
                      }
                      
                  });
                });
                  
                return false;
              }
          });
        }

    };
}();

