jQuery(document).ready(function() {
	App.init();
	StyleSwitcher.initStyleSwitcher();
  $("#recientes").addClass('active');
});

moment().locale('es')

// Initialize Firebase
var config = {
  apiKey: "AIzaSyB8-HyHdHDeMkEd4rV1Puy9hVvkqGasku4",
  authDomain: "sadtec-71e39.firebaseapp.com",
  databaseURL: "https://sadtec-71e39.firebaseio.com",
  projectId: "sadtec-71e39",
  storageBucket: "sadtec-71e39.appspot.com",
  messagingSenderId: "216969228312"
};
firebase.initializeApp(config);

//Por si quiere registrar una categoría
/*firebase.database().ref('Categorias/').push({
  categoria: "Automática"
});*/

$("#tablaResultados").html("")
$("#tablaResultados").append(
  '<tr class="col-12 titleTable">\
       <td class="col-4">Mes/Día/Año</td>\
       <td class="col-4">Título</td>\
       <td class="col-4">Categoría</td>\
   </tr>'
  )

var query = firebase.database().ref("Documentos").orderByChild("nombre");
query.once("value").then(function(snapshot) {
  snapshot.forEach(function(childSnapshot) {
      // key will be "ada" the first time and "alan" the second time
      var key = childSnapshot.key;
      var nombre = childSnapshot.val().nombre;
      var categoria = childSnapshot.val().categoria;
      var url = childSnapshot.val().url;
      var fecha = moment(childSnapshot.fecha).format('L');
      $("#tablaResultados").append(
        '<tr class="col-12">\
          <td class="date">'+fecha+'</td>\
          <td class="file"><a target="_blank" href="'+url+'">'+nombre+'</a></td>\
          <td class="file">'+categoria+'</a></td>\
        </tr>'
      )
      });
});
                      
                      
