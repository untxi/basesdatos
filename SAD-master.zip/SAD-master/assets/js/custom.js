function nav() {
    var x = document.getElementById("myTopnav");
    if (x.className === "col-12 topnav") {
        x.className += " responsive";
      document.getElementById("myTopNav").style.background="var(--orange)";
        document.getElementById("active").style.background="var(--blue)";
    } else {
        x.className = "col-12 topnav";
        document.getElementById("myTopNav").style.background="var(--blue)";
        document.getElementById("active").style.background="var(--orange)";
    }
 }

document.addEventListener("click",buscar);
function buscar(){
    var but = document.getElementById("buscarButton");
    var res = document.getElementById("verResult");
    
    if(res.style.display === "none"){
        res.style.display = "block";
        but.value = "Limpiar Resultados";
    }else{
        res.style.display = "none";
        but.value = "Buscar";
    }
}