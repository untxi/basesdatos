jQuery(document).ready(function() {
	App.init();
	StyleSwitcher.initStyleSwitcher();
  Validation.initValidation();
  $("#registrar").addClass('active');
});

moment().locale('es')

// Initialize Firebase
var config = {
  apiKey: "AIzaSyB8-HyHdHDeMkEd4rV1Puy9hVvkqGasku4",
  authDomain: "sadtec-71e39.firebaseapp.com",
  databaseURL: "https://sadtec-71e39.firebaseio.com",
  projectId: "sadtec-71e39",
  storageBucket: "sadtec-71e39.appspot.com",
  messagingSenderId: "216969228312"
};
firebase.initializeApp(config);

//Por si quiere registrar una categoría
/*firebase.database().ref('Categorias/').push({
  categoria: "Automática"
});*/


function cargarCategorias(){
  $("#myCat")
      .find('option')
      .remove()
      .end()
      .append('<option value="0">Seleccione una Categoría</option>')
      .val("0")
  ;
  var query = firebase.database().ref("Categorias").orderByChild("categoria");
  query.once("value").then(function(snapshot) {
    snapshot.forEach(function(childSnapshot) {
        // key will be "ada" the first time and "alan" the second time
        var key = childSnapshot.key
        var categoria = childSnapshot.val().categoria
        if (categoria != "Automática"){
          html = '<option value="'+key+'">'+categoria+'</option>'
          $("#myCat").append(html);
        }
    });
  });
}

cargarCategorias();


var Validation = function () {

    return {
        
        //Validation
        initValidation: function () {
          $("#docRegisterForm").validate({                   
              // Rules for form validation
              rules:
              {
                  docName:
                  {
                      required: true
                  },
                  docDesc:
                  {
                      required: true
                  },
                  docFile:
                  {
                    required: true
                  },
                  categoria:
                  {
                    checkCat: true
                  }
              },
                                  
              // Messages for form validation
              messages:
              {
        
                  docName:
                  {
                    required: 'Por favor, ingrese el nombre del documento'
                  },
                  docDesc:
                  {
                    required: 'Por favor, ingrese la descripción del documento'
                  },
                  docFile:
                  {
                    required: 'Debe seleccionar un documento para registar'
                  },
                  categoria:
                  {
                    checkCat: 'Debe seleccionar una categoría o marcar la casilla'
                  }
              },   
              
              // Do not change code below
              errorPlacement: function(error, element)
              {
                  error.insertAfter(element.parent());
             
              },
              submitHandler: function(form)
              {
                var formData = $(form).serializeArray()               
                var docName = formData[0]["value"];
                var docDesc = formData[1]["value"];
                var cat = "Automática"
                if ($("#myCat").val() != "0"){
                  cat = $("#myCat").find(":selected").text();
                }
                if ($("#myCat").val() != "0" && $("#catAuto").is(":checked")){
                  alert("La categorización automática ignora la categoría seleccionada.");
                }
                var file = $("#docFile").get(0).files[0];
                // Create a root reference
                var storageRef = firebase.storage().ref();

                // Create a reference to 'mountains.jpg'
                var mountainsRef = storageRef.child(file.name);

                // Create a reference to 'images/mountains.jpg'
                var mountainImagesRef = storageRef.child('docs/'+file.name);
                link = mountainsRef.put(file)

                var percentVal = '0%';
                $('.bar').width(percentVal)
                $('.percent').html(percentVal);

                link.on('state_changed', function(snapshot){
                  // Observe state change events such as progress, pause, and resume
                  // Get task progress, including the number of bytes uploaded and the total number of bytes to be uploaded
                  var progress = ((snapshot.bytesTransferred / snapshot.totalBytes) * 100).toFixed(4);


                  var percentVal = progress + '%';
                  $('.bar').width(percentVal)
                  $('.percent').html(percentVal);



                  console.log('Upload is ' + progress + '% done');
                  switch (snapshot.state) {
                    case firebase.storage.TaskState.PAUSED: // or 'paused'
                      console.log('Upload is paused');
                      break;
                    case firebase.storage.TaskState.RUNNING: // or 'running'
                      console.log('Upload is running');
                      break;
                  }
                }, function(error) {
                  // Handle unsuccessful uploads
                }, function() {
                  // Handle successful uploads on complete
                  // For instance, get the download URL: https://firebasestorage.googleapis.com/...
                  var percentVal = '100%';
                  $('.bar').width(percentVal)
                  $('.percent').html(percentVal);
                  var downloadURL = link.snapshot.downloadURL;
                  firebase.database().ref('Documentos/').push({
                    nombre: docName,
                    desc: docDesc,
                    url: downloadURL,
                    fecha: moment().valueOf(),
                    categoria: cat
                  });
                  alert("Documento guardado correctamente");
                    $(form)[0].reset();
                });
                  
                return false;
              }
          });

          $.validator.addMethod("checkCat", function(value) {
            return $("#myCat").val() != "0" || $("#catAuto").is(":checked")     
          });
        }

    };
}();

