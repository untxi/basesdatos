CREATE USER `hadoop`@`localhost` IDENTIFIED BY 'hadoop123';
GRANT ALL ON HadoopClimate.* TO 'hadoop'@'localhost';