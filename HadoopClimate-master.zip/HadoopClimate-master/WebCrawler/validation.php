<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>My Web Crawler - Caeli</title>
</head>
<body>
	<div>
		<p>TuTiempo.net status</p>
		<Button id="check">Check</Button>
	</div>
	<script type="text/javascript" src="jquery.js"></script>
	<script type="text/javascript" src="ajax.js"></script>
</body>
</html>