<?php
	printf(substr("1234;56", 4, -1));
?>