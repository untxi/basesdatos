<?php
        define('HOST','localhost:3306');
        define('USER', 'hadoop');
        define('PASS', 'hadoop123');
        define('DB', 'HadoopClimate');
        date_default_timezone_set('America/Costa_Rica');
?>