<?php
$cluster   = Cassandra::cluster()->withCredentials('mycassy','2016')->build();                 // connects to localhost by default
$keyspace  = 'goshop';
$session   = $cluster->connect($keyspace);        // create session, optionally scoped to a keyspace
$result = $session->execute(new Cassandra\SimpleStatement('SELECT categorianame 
FROM categoria where categorianame = \'hola\' allow filtering'));
if ($result->count() == 0){
	printf("nada");
}
foreach ($result as $row) {
    printf("The keyspace \"%s\".\n", $row['categorianame']);
}
?>