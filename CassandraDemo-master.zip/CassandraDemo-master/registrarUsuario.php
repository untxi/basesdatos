<?php
	$name = $_POST['name'];
	$lastName = $_POST['lastName'];
	$phone = (int) $_POST['phone'];
	$email = $_POST['email'];
	$address = $_POST['address'];
	$username = $_POST['username'];
	$password = $_POST['password'];

	$cluster   = Cassandra::cluster()->withCredentials('mycassy','2016')->build();                 // connects to localhost by default
	$keyspace  = 'goshop';
	$session   = $cluster->connect($keyspace);        // create session, optionally scoped to a keyspace




	$result = $session->executeAsync(new Cassandra\SimpleStatement('INSERT into usuario (username, password, nombre, apellidos, telefono, direccion, email) VALUES (?,?,?,?,?,?,?)'), new Cassandra\ExecutionOptions(array(
        'arguments' => array($username, $password, $name, $lastName, $phone, $address, $email)
    )));

?>