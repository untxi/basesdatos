<?php
	if (!isset($_COOKIE['session'])){
		echo '<script>alert("Inicia sesión para acceder a tu carrito de compras!"); window.location.href = "index.php";</script>';
	}
	$cluster   = Cassandra::cluster()->withCredentials('mycassy','2016')->build();                 // connects to localhost by default
	$keyspace  = 'goshop';
	$session   = $cluster->connect($keyspace);        // create session, optionally scoped to a keyspace
	$idCarrito = $_COOKIE['carrito'];
	$uuidCarrito = new Cassandra\Uuid($idCarrito);

	//Se extraen los id de los productos actuales del usuario	
	$productosActuales = $session->execute(new Cassandra\SimpleStatement('SELECT productoid FROM ProductoPorUsuario where carritoid = ? allow filtering;'), new Cassandra\ExecutionOptions(array(
    'arguments' => array($uuidCarrito)
	)));


	//Se extra la cantidad de productos actuales del usuario
	$cantProductos = $session->execute(new Cassandra\SimpleStatement('SELECT count(*) AS totalProds FROM ProductoPorUsuario where carritoid = ? allow filtering;'), new Cassandra\ExecutionOptions(array(
    'arguments' => array($uuidCarrito)
	)))->first();


	//Se extrae el total por pagar del carrito
	$infoCarrito = $session->execute(new Cassandra\SimpleStatement('SELECT totalporpagar from carrito where carritoid = ? allow filtering;'), new Cassandra\ExecutionOptions(array(
        'arguments' => array($uuidCarrito)
    )))->first();

?>

<!--A Design by W3layouts 
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>GoShop | Carrito</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!--theme-style-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--fonts-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
<!--//fonts-->
<script src="js/jquery.min.js"></script>
<!--script-->
</head>
<body> 
	<?php include('header.php') ?>
	<!---->
	<div class="container">
			<div class="shoes-grid">
			<a href="single.html">
			<div class="wrap-in">
				<div class="wmuSlider example1 slide-grid">		 
				   
					 </a>
	            </div>
	          </div>
	           	</a>
	   		      <!---->
	   		     <div class="products">
	   		     	<h5 class="latest-product">Cantidad de Productos: <?php echo $cantProductos['totalprods']; ?> -  Total Por Pagar = ₡<?php echo number_format((float) $infoCarrito['totalporpagar'], 2, '.', ''); ?></h5>		     
	   		     </div>

	   		     <div class="product-left">

	   		     <?php
	   		     	foreach ($productosActuales as $producto){
	   		     		$uuidProducto = new Cassandra\Uuid($producto['productoid']);
	   		     		$productoAct = $session->execute(new Cassandra\SimpleStatement('SELECT * FROM producto where productoid = ? allow filtering;'), new Cassandra\ExecutionOptions(array(
						    'arguments' => array($uuidProducto)
							)))->first();
	   		     		echo '<div class="col-md-4 chain-grid grid-top-chain">
	   		     		<a id="'.$productoAct['productoid'].'" class="productInCategory" href="javascript:void(0)"><img class="img-responsive chain" src="'.$productoAct['fotos']->values()[0].'" alt=" " /></a>
	   		     		<div class="grid-chain-bottom">
	   		     			<h6><a id="'.$productoAct['productoid'].'" class="productInCategory" href="javascript:void(0)">'.$productoAct['nombre'].'</a></h6>
	   		     			<div class="star-price">
	   		     				<div class="dolor-grid"> 
		   		     				<span class="actual">₡'.number_format((float) $productoAct['precio'], 2, '.', '').'</span>
	   		     				</div>
	   		     				<div class="clearfix"> </div>
							</div>
	   		     		</div>
	   		     		</div>';
	   		     	}
	   		     ?>   	
	   		     	
	   		     	 <div class="clearfix"> </div>
	   		     </div>

	   		     
	   		     <div class="clearfix"> </div>
				<div class="register-but">
				   <form id="checkout" action="checkoutCarrito.php">
					   <input  type="submit" value="Finalizar Compra" <?php if ($cantProductos['totalprods'] == 0) {echo 'disabled';}?>>
					   <div class="clearfix"> </div>
				   </form>
				</div>
	   		   </div>   
			   <?php include('sidebar.php') ?>
	   		    <div class="clearfix"> </div>        	         
		</div>
	
	<!---->
	<?php include('footer.php') ?>
</body>
</html>