<div class="footer">
	<div class="footer-top">
		<div class="container">
			<div class="latter">
				<h6>&copy KLC, VCD, AAB, SAL</h6>
				<div class="clearfix"> </div>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
</div>	