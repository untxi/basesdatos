<?php 
	$product = $_GET['product'];
	$productuuid = new Cassandra\Uuid($product);

	$cluster   = Cassandra::cluster()->withCredentials('mycassy','2016')->build();                 // connects to localhost by default
	$keyspace  = 'goshop';
	$session   = $cluster->connect($keyspace);        // create session, optionally scoped to a keyspace
	$producto = $session->execute(new Cassandra\SimpleStatement('SELECT * FROM producto where productoid = ? allow filtering;'), new Cassandra\ExecutionOptions(array(
        'arguments' => array($productuuid)
    )))->first();
?>

<!--A Design by W3layouts 
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>GoShop | <?php echo $producto['nombre'] ?></title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!--theme-style-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
<link rel="stylesheet" href="css/etalage.css" type="text/css" media="all" />
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--fonts-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
<!--//fonts-->
<script src="js/jquery.min.js"></script>

<script src="js/jquery.etalage.min.js"></script>
<script>
			jQuery(document).ready(function($){

				$('#etalage').etalage({
					thumb_image_width: 300,
					thumb_image_height: 400,
					source_image_width: 900,
					source_image_height: 1200,
					show_hint: true,
					click_callback: function(image_anchor, instance_id){
						alert('Callback example:\nYou clicked on an image with the anchor: "'+image_anchor+'"\n(in Etalage instance: "'+instance_id+'")');
					}
				});

			});
		</script>

</head>
<body> 
	</body>
	<?php include('header.php') ?>
	<!---->
	
	 <div class="container"> 
	 	
	 	<div class=" single_top">
	      <div class="single_grid">
				<div class="grid images_3_of_2">
						<ul id="etalage">
						<?php
						$fotos = $producto['fotos']->values();
						foreach ($fotos as $foto) {
							echo '<li>
									<img class="etalage_thumb_image" src="'.$foto.'" class="img-responsive" />
									<img class="etalage_source_image" src="'.$foto.'" class="img-responsive" title="" />
							</li>';
						}
							

						?>
						</ul>
						 <div class="clearfix"> </div>		
				  </div> 
				  <div class="desc1 span_3_of_2">
				  
					
					<h4><?php echo $producto['nombre'] ?></h4>
				<div class="cart-b">
					<div class="left-n ">₡<?php echo number_format((float) $producto['precio'], 2, '.', '') ?></div>
					
					<button class="btn btn-default" id="botonCompra" type="button">Agregar al Carrito</button> 

					<input type="hidden" id="productoID" value=<?php echo(json_encode($_GET['product'])); ?>>
					<input type="hidden" id="categoriaNombre" value=<?php echo(json_encode($producto['categoria'])); ?>>
					<input type="hidden" id="precioProd" value=<?php echo number_format((float) $producto['precio'], 2, '.', '') ?>>

				    <div class="clearfix"></div>
				 </div>
			   	<p><?php echo $producto['caracteristicas']?></p>
			   
				
				</div>
          	    <div class="clearfix"> </div>
          	   </div>
          	    	<div class="toogle">
				     	<h3 class="m_3">Product Details</h3>
				     	<p class="m_text"><?php echo $producto['descripcion'] ?></p>
				     </div>	
          	   </div>
          	   
          	   <!---->
<?php include('sidebar.php') ?>
<div class="clearfix"> </div>			
		</div>
	<!---->
	<?php include('footer.php') ?>

<script src="js/botonCompra.js"></script>
</body>
</html>