<?php
	if (!isset($_COOKIE['session'])){
		echo '<script>alert("Inicia sesión para obtener recomendaciones!"); window.location.href = "index.php";</script>';
	}

    $cluster   = Cassandra::cluster()->withCredentials('mycassy','2016')->build();                 // connects to localhost by default
    $keyspace  = 'goshop';
    $session   = $cluster->connect($keyspace);        // create session, optionally scoped to a keyspace
    $username = $_COOKIE['id'];

    $result = $session->execute(new Cassandra\SimpleStatement("SELECT categoriaprod, cantcomprados FROM ProductoPorUsuario where username = ? ALLOW FILTERING"), new Cassandra\ExecutionOptions(array(
        'arguments' => array($username)
    )));

    if($result->count() == 0){
    	echo '<script>alert("No ha realizado compras! Realiza tu primera compra para obtener recomendaciones!"); window.location.href = "index.php";</script>';
    }

    $array_temp = array();

    foreach ($result as $categoria) {
        if (array_key_exists($categoria["categoriaprod"], $array_temp)) {
            $array_temp[$categoria["categoriaprod"]] +=  $categoria["cantcomprados"];
        } else {
            $array_temp[$categoria["categoriaprod"]] =  $categoria["cantcomprados"];
        }
    }

    $key = array_keys($array_temp, max($array_temp))[0];

    $productos = $session->execute(new Cassandra\SimpleStatement('SELECT * FROM producto where categoria = ? limit 5 allow filtering;'), new Cassandra\ExecutionOptions(array(
        'arguments' => array($key)
    )));

?>


<!--A Design by W3layouts 
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>GoShop | Recomendaciones</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!--theme-style-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--fonts-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
<!--//fonts-->
<script src="js/jquery.min.js"></script>
<!--script-->
</head>
<body> 
	<?php include('header.php') ?>
	<!---->
	<div class="container">
			<div class="shoes-grid">
			<a href="single.html">
			<div class="wrap-in">
				<div class="wmuSlider example1 slide-grid">		 
				   
					 </a> 
	            </div>
	          </div>
	   		     <div class="clearfix"> </div>
	   		     <ul id="flexiselDemo1">

	   		     <?php
	   		     	foreach ($productos as $row) {
	   		     		echo '<li><img src="'.$row['fotos']->values()[0].'" /><div class="grid-flex"><a id="'.$row['productoid'].'" class="productInCategory" href="javascript:void(0)">'.$row['nombre'].'</a><p>₡'.number_format((float) $row['precio'], 2, '.', '').'</p></div></li>';
	   		     	}
	   		     ?>
		 </ul>
	    <script type="text/javascript">
		 $(window).load(function() {
			$("#flexiselDemo1").flexisel({
				visibleItems: 5,
				animationSpeed: 1000,
				autoPlay: true,
				autoPlaySpeed: 3000,    		
				pauseOnHover: true,
				enableResponsiveBreakpoints: true,
		    	responsiveBreakpoints: { 
		    		portrait: { 
		    			changePoint:480,
		    			visibleItems: 1
		    		}, 
		    		landscape: { 
		    			changePoint:640,
		    			visibleItems: 2
		    		},
		    		tablet: { 
		    			changePoint:768,
		    			visibleItems: 3
		    		}
		    	}
		    });
		    
		});
	</script>
	<script type="text/javascript" src="js/jquery.flexisel.js"></script>
	   		   </div>   
			   <?php include('sidebar.php') ?>       	         
	</div>
	
	<!---->
	<?php include('footer.php') ?>
</body>
</html>