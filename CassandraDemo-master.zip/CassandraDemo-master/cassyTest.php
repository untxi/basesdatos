<?php
$cluster   = Cassandra::cluster()->build();                 // connects to localhost by default
$keyspace  = 'system_schema';
$session   = $cluster->connect();        // create session, optionally scoped to a keyspace
$result = $session->execute(new Cassandra\SimpleStatement('SELECT keyspace_name, table_name
FROM system_schema.tables'));

foreach ($result as $row) {
printf("The keyspace \"%s\" has a table \"%s\".\n", $row['keyspace_name'], $row['table_name']);
}
?>