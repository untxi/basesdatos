<?php
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);

	$username = $_COOKIE['id'];
	$carritoID = new Cassandra\Uuid($_COOKIE['carrito']);

	$cluster   = Cassandra::cluster()->withCredentials('mycassy','2016')->build();                 // connects to localhost by default
	$keyspace  = 'goshop';
	$session   = $cluster->connect($keyspace);        // create session, optionally scoped to a keyspace
	

	// Obtenemos el precio anterior
	$actualizarCarrito = $session->execute(new Cassandra\SimpleStatement(
		'UPDATE carrito SET estado = false where carritoid = ? AND usuario = ?;'), new Cassandra\ExecutionOptions(array(
        'arguments' => array($carritoID, $username))));

	// Creamos un nuevo carrito y le sacamos el ID
	$crear_carrito = $session->execute(
		new Cassandra\SimpleStatement('INSERT INTO carrito (carritoID, estado, usuario, totalPorPagar) VALUES (now(), true, ?, 0);'), 
		new Cassandra\ExecutionOptions(array(
	   		'arguments' => array($username)
		)
	));

	// Obtenemos el id del nuevo carrito
	$carritoID = $session->execute(
		new Cassandra\SimpleStatement('SELECT carritoid FROM carrito WHERE usuario = ? AND estado = true allow filtering'), 
		new Cassandra\ExecutionOptions(array(
	   		'arguments' => array($username)
		)
	))->first()['carritoid'];


	setcookie('id', $username, 0);
    setcookie('carrito', $carritoID);

	echo '<script>alert("Compra finalizada correctamente! Gracias por preferirnos!"); window.location.href = "index.php";</script>';

?>