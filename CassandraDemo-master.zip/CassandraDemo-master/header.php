<!--header-->
	<div class="header">
		<div class="bottom-header">
			<div class="container">
				<div class="header-bottom-left">
					<div class="logo">
						<a href="index.php"><img src="images/logo.png" alt=" " /></a>
					</div>
					<div class="search">
						<input id="searchText" type="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}" >
						<input id="search" type="submit"  value="BUSCAR">

					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="header-bottom-right">				
						<div class="account">
						<a href="recom.php"><span> </span>RECOMENDACIONES</a></div>
							<ul class="login">

								<?php
    								if(isset($_COOKIE['session'])) {
    								 	$cluster   = Cassandra::cluster()->withCredentials('mycassy','2016')->build();                 // connects to localhost by default
										$keyspace  = 'goshop';
										$session   = $cluster->connect($keyspace);        // create session, optionally scoped to a keyspace
    									$result = $session->execute(new Cassandra\SimpleStatement('SELECT nombre, apellidos 
											FROM usuario where sesion = ? allow filtering'), new Cassandra\ExecutionOptions(array(
										        'arguments' => array($_COOKIE['session'])
										    )));


    									$nombre = $result[0]['nombre'];
    									$apellido = $result[0]['apellidos'];
    									echo "Bienvenido, $nombre $apellido - " ;
    									echo '<a href="logout.php">LOG OUT</a>';
    								} else {
										echo '<li><a href="login.php"><span> </span>LOGIN</a></li> |';
										echo '<li ><a href="register.php">SIGNUP</a></li>';
									}
								?>
							</ul>
						<div class="cart"><a href="cart.php"><span> </span>CARRITO</a></div>
					<div class="clearfix"> </div>
				</div>
				<div class="clearfix"> </div>	
			</div>
		</div>
	</div>

<!-- custom form validation script for this page-->
<script src="js/functions.js"></script>