<?php

	$cluster   = Cassandra::cluster()->withCredentials('mycassy','2016')->build();                 // connects to localhost by default
	$keyspace  = 'goshop';
	$session   = $cluster->connect($keyspace);        // create session, optionally scoped to a keyspace

	if(isset($_GET['cat'])){
		$category = $_GET['cat'];
		$productos = $session->execute(new Cassandra\SimpleStatement('SELECT * FROM ProductosPorCategoria where categoria = ? allow filtering;'), new Cassandra\ExecutionOptions(array(
        'arguments' => array($category)
    	)));

		$infoCategoria = $session->execute(new Cassandra\SimpleStatement('SELECT count(*) from goshop.producto where categoria = ? allow filtering;'), new Cassandra\ExecutionOptions(array(
	        'arguments' => array($category)
	    )))->first();
	} else {
		$category = 'Todos los Productos';
		$infoCategoria = $session->execute(new Cassandra\SimpleStatement('SELECT count(*) from goshop.producto;'))->first();
		$productos = $session->execute(new Cassandra\SimpleStatement('SELECT * FROM ProductosPorCategoria;'));
	}


?>

<!--A Design by W3layouts 
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>GoShop | Productos</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!--theme-style-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--fonts-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
<!--//fonts-->
<script src="js/jquery.min.js"></script>


<!--script-->
</head>
<body> 
	<?php include('header.php') ?>
	<!---->
	<!-- start content -->
	<div class="container">
		
	<div class="women-product">
		<div class=" w_content">
			<div class="women">
				<!-- Nombre de categoría y cantidad de items en ella -->
				<a href="#"><h4><?php echo $category." -" ?> <span> Total de Productos: <?php echo $infoCategoria['count'] ?></span> </h4></a>
				<ul class="w_nav">
					<li>Sort : </li>
			     	<li><a class="active" href="#">popular</a></li> |
			     	<li><a href="#">new </a></li> |
			     	<li><a href="#">price: Low High </a></li> 
			     <div class="clearfix"> </div>	
			     </ul>
			     <div class="clearfix"> </div>	
			</div>
		</div>
		<!-- grids_of_4 -->
		<div class="grid-product">

		<!-- Inicio de código de cada producto -->
		<?php
		foreach ($productos as $row) {
			echo '<div class="col-md-4 chain-grid grid-top-chain">
	   		     		<a id="'.$row['productoid'].'" class="productInCategory" href="javascript:void(0)"><img class="img-responsive chain" src="'.$row['fotos']->values()[0].'" alt=" " /></a>
	   		     		<span class="star"> </span>
	   		     		<div class="grid-chain-bottom">
	   		     			<h6><a id="'.$row['productoid'].'" class="productInCategory" href="javascript:void(0)">'.$row['nombre'].'</a></h6>
	   		     			<div class="star-price">
	   		     				<div class="dolor-grid"> 
		   		     				<span class="actual">₡'.number_format((float) $row['precio'], 2, '.', '').'</span>
	   		     				</div>
	   		     				<div class="clearfix"> </div>
							</div>
	   		     		</div>
	   		     		</div>';
		}
		?>

		<!--
		<div class="  product-grid">
			<div class="content_box"><a href="single.php">
				<div class="left-grid-view grid-view-left">
				   	 <img src="images/pic13.jpg" class="img-responsive watch-right" alt=""/>
			   	   	<div class="mask">
			            <div class="info">Quick View</div>
			        </div>
			   	  </a>
			</div>
			    <h4><a href="#">Nombre Producto - PRECIO</a></h4>
			     <p>Descripción pequeña</p>
			</div>
		  </div>
		  -->
		  <!-- Fin de código de cada producto -->

			<div class="clearfix"> </div>
		</div>
	</div>
	<?php include('sidebar.php') ?>
	<div class="clearfix"> </div>
</div>
	<!---->
	<?php include('footer.php') ?>
	<!-- custom form validation script for this page-->
<script src="js/functions.js"></script>
</body>
</html>