<!-- Obtener las categorías desde Cassandra con PHP -->
<?php
$cluster   = Cassandra::cluster()->withCredentials('mycassy','2016')->build();                 // connects to localhost by default
$keyspace  = 'goshop';
$session   = $cluster->connect();        // create session, optionally scoped to a keyspace
$result = $session->execute(new Cassandra\SimpleStatement('SELECT categorianame 
FROM goshop.categoria'));

?>

<div class="sub-cate">
	<div class=" top-nav rsidebar span_1_of_left">
		<h3 class="cate">CATEGORÍAS</h3>
		<ul class="menu">
		<ul class="kid-menu ">
		<?php
			foreach ($result as $row) {
			    echo '<li><a class="category" href="javascript:void(0)">'.$row['categorianame'].'</a></li>';
			}
		?>
		</ul>
		</ul>
	</div>
	<a class="view-all all-product" href="product.php">VER TODOS LOS PRODUCTOS<span> </span></a> 	
	<!-- custom form validation script for this page-->
	<script src="js/functions.js"></script>
</div>