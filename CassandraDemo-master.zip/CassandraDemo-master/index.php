<!--A Design by W3layouts 
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>GoShop | Home</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!--theme-style-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--fonts-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
<!--//fonts-->
<script src="js/jquery.min.js"></script>
<!--script-->
</head>
<body> 
	<?php include('header.php') ?>
	<!---->
	<div class="container">
			<div class="shoes-grid">
			<div class="wrap-in">
				<div class="wmuSlider example1 slide-grid">		 
				   <div class="wmuSliderWrapper">

					   <article style="position: absolute; width: 100%; opacity: 0;">					
						<div class="banner-matter">
						<div class="col-md-5 banner-bag">
							<img class="img-responsive " src="images/bag.jpg" alt=" " />
							</div>
							<div class="col-md-7 banner-off">							
								<h2>CASSANDRA DEMO</h2>
								<label>GO<b>SHOP</b></label>
								<p>Creado por Kevin Lobo Chinchilla, Víctor Chaves Díaz, Samantha Arburola León, Andrea Abarca Baltodano</p>
							</div>
							
							<div class="clearfix"> </div>
						</div>
						
					 	</article>
					 	<article style="position: absolute; width: 100%; opacity: 0;">					
						<div class="banner-matter">
						<div class="col-md-5 banner-bag">
							<img class="img-responsive " src="images/bag1.jpg" alt=" " />
							</div>
							<div class="col-md-7 banner-off">							
								<h2>CASSANDRA DEMO</h2>
								<label>GO<b>SHOP</b></label>
								<p>Creado por Kevin Lobo Chinchilla, Víctor Chaves Díaz, Samantha Arburola León, Andrea Abarca Baltodano</p>
							</div>
							
							<div class="clearfix"> </div>
						</div>
						
					 	</article>
					 	
					 	<article style="position: absolute; width: 100%; opacity: 0;">					
						<div class="banner-matter">
						<div class="col-md-5 banner-bag">
							<img class="img-responsive " src="images/bag.jpg" alt=" " />
							</div>
							<div class="col-md-7 banner-off">							
								<h2>CASSANDRA DEMO</h2>
								<label>GO<b>SHOP</b></label>
								<p>Creado por Kevin Lobo Chinchilla, Víctor Chaves Díaz, Samantha Arburola León, Andrea Abarca Baltodano</p>
							</div>
							
							<div class="clearfix"> </div>
						</div>						
					 	</article>
						
					 </div>
					 </a>
	                <ul class="wmuSliderPagination">
	                	<li><a href="#" class="">0</a></li>
	                	<li><a href="#" class="">1</a></li>
	                	<li><a href="#" class="">2</a></li>
	                </ul>
					 <script src="js/jquery.wmuSlider.js"></script> 
				  <script>
	       			$('.example1').wmuSlider();         
	   		     </script> 
	            </div>
	          </div>
	           	</a>
	   		      <!---->
	   		     	 <div class="clearfix"> </div>
	   		     <div class="clearfix"> </div>
	   		   </div>   
			   <?php include('sidebar.php') ?>
	   		    <div class="clearfix"> </div>        	         
		</div>
	
	<!---->
	<?php include('footer.php') ?>
</body>
</html>