<!-- Obtener las categorías desde Cassandra con PHP -->
<?php
$username = $_POST['username'];
$password = $_POST['password'];
$cluster   = Cassandra::cluster()->withCredentials('mycassy','2016')->build();                 // connects to localhost by default
$keyspace  = 'goshop';
$session   = $cluster->connect();        // create session, optionally scoped to a keyspace
$result = $session->execute(new Cassandra\SimpleStatement('SELECT username, password 
FROM usuario where username = $username and password = $password;'));

if ($result->count() == 0){
	echo '<script>alert("Nombre de usuario o contraseña es incorrecto")</script>';
} else {
	echo '<script>alert("Nombre de Usuario existe!")</script>';
}
//Usar esto de session en el link <a> de la categoría para enviarla a product y cargar los productos de la categoría.
$_SESSION['var'] = 5;

?>