<?php
	setcookie('id', '', 0);
	setcookie('session', '', 0);
	setcookie('carrito', '');
	echo '<script>alert("Gracias por visitarnos!"); window.location.href = "index.php";</script>'
?>