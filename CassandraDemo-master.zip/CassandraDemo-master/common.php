<?php
    function update_cookie($user, $session, $carritoID) {
        setcookie('id', $user, 0);
        setcookie('session', $session, 0);
        setcookie('carrito', $carritoID);
    }
    
    function cerrar_sesion() {
        setcookie('id', '', 0);
        setcookie('session', '', 0);
        setcookie('carrito', '');
    }
?>