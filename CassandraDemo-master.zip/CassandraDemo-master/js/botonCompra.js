$(document).ready(function(){
	$("#botonCompra").on('click', function(){
		$.ajax({
            type: "POST",
            url: "agregarProducto.php",
            dataType: "json",
            data: {
                productoID: $("#productoID").val(),
                categoria: $("#categoriaNombre").val(),
                precio: $("#precioProd").val()
            },
            success: function(data) {
                alert("Producto agregado al carrito!");
            },
            error : function(data) {
                for(var key in data) {
                    console.log(data[key]);
                }
                
                alert("Ha ocurrido un error. Verifica que hayas iniciado sesión.");
            }
		});
	});
});