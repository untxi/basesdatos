var Script = function () {


    $().ready(function() {

        $("#cancel").on('click', function(){
            location.reload();
        });

        $('a.category').on('click', function(){
            console.log($(this).html())
            var category = $(this).html();
            window.location.href = "product.php?cat=" + category;
        });

        $('#search').on('click', function(){
            var search = $('#searchText').val();
            if (search != ""){
                window.location.href = "productSearch.php?search=" + search;
            }
        });



        $('a.productInCategory').on('click', function(){
            console.log(this.id);
            var product = this.id;
            window.location.href = "single.php?product=" + product;

        });


        //Función para registrarse
        $("#registerForm").on('submit', function(){
        	var name = $("#name").val();
        	var lastName = $("#lastName").val();
        	var phone = $('#phone').val();
        	var email = $("#email").val();
        	var address = $("#address").val();
        	var username = $("#username").val();
        	var password = $("#password").val();
        	var confirmPassword = $("#confirmPassword").val();
        	if (password != confirmPassword){
        		alert("Contraseñas diferentes")
        		return false
        	}
            $.ajax({
                    type: "POST",
                    url: "registrarUsuario.php",
                    dataType: "json",
                    data: {
                        name: name,
                        lastName: lastName,
                        phone: phone,
                        email: email,
                        address: address,
            			username: username,
            			password: password
                    },
                    success: function(data) {
                        alert("Usuario registrado con éxito!");
                    },
                    error : function(data) {
                        alert(JSON.stringify(data));
                        alert("Ha ocurrido un error.");
                    }
                });

            return false;
        });
    });


}();