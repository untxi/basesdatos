<!-- Obtener las categorías desde Cassandra con PHP -->
<?php
	include('common.php');

	if (isset($_POST['login'])){
		$username = $_POST['username'];
		$password = $_POST['password'];
		$cluster   = Cassandra::cluster()->withCredentials('mycassy','2016')->build();                 // connects to localhost by default
		$keyspace  = 'goshop';
		$session   = $cluster->connect($keyspace);        // create session, optionally scoped to a keyspace



		$result = $session->execute(new Cassandra\SimpleStatement('SELECT username, password 
		FROM usuario where username = ? and password = ? allow filtering'), new Cassandra\ExecutionOptions(array(
	        'arguments' => array($username, $password)
	    )));



		if ($result->count() == 0){
			echo '<script>alert("Nombre de usuario o contraseña es incorrecto")</script>';
		} else {
			// Hay que sacar el ultimo carrito, si existe, solo se saca, si no, se crea uno nuevo
			$query_carrito = $session->execute(
				new Cassandra\SimpleStatement('SELECT carritoid FROM carrito WHERE usuario = ? AND estado = true allow filtering'), 
				new Cassandra\ExecutionOptions(array(
			   		'arguments' => array($username)
				)
			));
			


			$carritoID = 0;

			if ($query_carrito->count() == 0) {
				// Creamos un nuevo carrito y le sacamos el ID
				$crear_carrito = $session->execute(
					new Cassandra\SimpleStatement('INSERT INTO carrito (carritoID, estado, usuario, totalPorPagar) VALUES (now(), true, ?, 0)'), 
					new Cassandra\ExecutionOptions(array(
				   		'arguments' => array($username)
					)
				));

				$query_carrito_2 = $session->execute(
					new Cassandra\SimpleStatement('SELECT carritoid FROM carrito WHERE usuario = ? AND estado = true allow filtering'), 
					new Cassandra\ExecutionOptions(array(
				   		'arguments' => array($username)
					)
				));

				$carritoID = $query_carrito_2[0]['carritoid'];
			} else {
				$carritoID = $query_carrito[0]['carritoid'];
			}

			$sesion = crypt($username + strval(time()));

			update_cookie($username, $sesion, $carritoID);

			$session->execute(
				new Cassandra\SimpleStatement('UPDATE usuario SET sesion = ? WHERE username = ?'), new Cassandra\ExecutionOptions(array(
				        'arguments' => array(strval($sesion), $username)
				    )));

			header('Location: index.php');
		}


	}
?>

<!--A Design by W3layouts 
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>GoShop | Login</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!--theme-style-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--fonts-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
<!--//fonts-->
<script src="js/jquery.min.js"></script>
</head>
<body> 
	<?php include('header.php') ?>
	<!---->
	<div class="container">
		
      	   <div class="account_grid">
			   <div class=" login-right">
			  	<h3>Clientes Registrados</h3>
				<p>Por favor, inicia sesión</p>
				<form id="bwarb" autocomplete="off" action="login.php" method="POST">
				  <div>
					<span>Nombre de Usuario<label>*</label></span>
					<input name="username" type="text"> 
				  </div>
				  <div>
					<span>Contraseña<label>*</label></span>
					<input name="password" type="password"> 
				  </div>
				  <input name="login" type="submit" value="Iniciar Sesión">
			    </form>
			   </div>	
			    <div class=" login-left">
			  	 <h3>NUEVOS CLIENTES</h3>
				 <p>Por favor, crea una cuenta para disfrutar de nuestros productos.</p>
				 <a class="acount-btn" href="register.php">Registrarse</a>
			   </div>
			   <div class="clearfix"> </div>
			 </div>
			 <?php include('sidebar.php') ?>
			  <div class="clearfix"> </div>
      	 </div>
	<!---->
	<?php include('footer.php') ?>
<!-- custom form validation script for this page-->
</body>
</html>