<?php
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);

	$username = $_COOKIE['id'];
	$carritoID = new Cassandra\Uuid($_COOKIE['carrito']);
	$productoID = new Cassandra\Uuid($_POST['productoID']);
	$categoria = $_POST['categoria'];
	$precioNuevo = number_format((float) $_POST['precio'], 2, '.', '');

	$cluster   = Cassandra::cluster()->withCredentials('mycassy','2016')->build();                 // connects to localhost by default
	$keyspace  = 'goshop';
	$session   = $cluster->connect($keyspace);        // create session, optionally scoped to a keyspace
	

	// Obtenemos el precio anterior
	$precioAnterior = number_format((float) $session->execute(new Cassandra\SimpleStatement(
		'SELECT totalporpagar FROM carrito where carritoid = ? allow filtering'), new Cassandra\ExecutionOptions(array(
        'arguments' => array($carritoID))))->first()['totalporpagar'], 2, '.', '');

	// Los sumamos
	$precioActual = $precioAnterior + $precioNuevo;

	 // Y actualizamos
	$session->execute(new Cassandra\SimpleStatement(
	 	'UPDATE carrito SET totalporpagar = ? WHERE carritoid = ? and usuario = ?'), new Cassandra\ExecutionOptions(array(
        'arguments' => array(new Cassandra\Float($precioActual), $carritoID, $username))))->first();

	$insertarEnTabla = $session->execute(new Cassandra\SimpleStatement(
		'INSERT INTO productoPorUsuario(carritoid, username, categoriaprod, productoid, cantcomprados)
			VALUES(?, ?, ?, ?, ?)'), new Cassandra\ExecutionOptions(array(
        'arguments' => array(
        	$carritoID,
        	$username,
        	$categoria,
        	$productoID,
        	1
        	)
    )))->first();
?>