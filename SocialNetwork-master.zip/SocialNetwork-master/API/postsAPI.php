<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once('PostsClass.php');

$serviceAPI = new PostAPI();

if (!isset($_POST["action"])){
    $array = array();
    $array["RETURN_CODE"] = "INVALID_VIDEO";
    echo json_encode($array);
    exit();
}

$action = $_POST["action"];


switch ($action) {
    //Posts
    case 1:
        $userId = $_COOKIE["id"];
        $postText = $_POST["postText"];

        $image = $_FILES["picture"]["error"] == 4 ? "null" : $_FILES["picture"];
        $video = $_FILES["video"]["error"] == 4 ? "null" : $_FILES["video"];

        $result = json_encode($serviceAPI->createPost($userId, $postText, $image, $video));
        echo $result;
        break;

    case 2:
    	$userId = $_COOKIE["id"];
    	$result = json_encode($serviceAPI->getPosts($userId));
        echo $result;
        break;
    case 3:
        $result = json_encode($serviceAPI->getMostRecentPostDatetime());
        echo $result;
        break;
    case 4:
        $userId = $_COOKIE["id"];
        $postId = $_POST["postId"];
        $result = json_encode($serviceAPI->likeOrDislikePost($postId, $userId));
        echo $result;
        break;
}

?>