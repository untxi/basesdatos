<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once('FollowsClass.php');

$serviceAPI = new FollowAPI();

$action = $_POST["action"];


switch ($action) {
    //Follow someone
    case 1:
        $userId = $_COOKIE["id"];
        $userToFollowId = $_POST["userToFollowId"];
        $result = json_encode($serviceAPI->followUser($userId, $userToFollowId));
        echo $result;
        break;

    //Get Followers of the actual user
    case 2:
    	$userId = $_COOKIE['id'];
    	$result = json_encode($serviceAPI->getFollowers($userId));
        echo $result;
        break;

    //Get users that the actual user follows.
    case 3:
        $userId = $_COOKIE['id'];
        $result = json_encode($serviceAPI->getFollowing($userId));
        echo $result;
        break;

    case 4:
        $userId = $_COOKIE['id'];
        $searchWord = $_POST["searchWord"];
        $result = json_encode($serviceAPI->searchUsers($userId,$searchWord));
        echo $result;
        break;
}

?>