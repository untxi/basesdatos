<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once('ProfileClass.php');

$serviceAPI = new ProfileAPI();

$action = $_POST["action"];


switch ($action) {
    //Load actual user profile
    case 1:
        $userId = $_POST["id"];
        $result = json_encode($serviceAPI->getUserProfile($userId));
        echo $result;
        break;
}

?>