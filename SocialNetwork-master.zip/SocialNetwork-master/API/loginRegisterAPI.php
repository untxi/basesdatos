<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once('LoginRegisterClass.php');

$serviceAPI = new LoginRegisterAPI();

$action = $_POST["action"];


switch ($action) {
    //Registro e inicio de sesión
    case 1:
    	$email = $_POST["email"];
    	$pass = $_POST["password"];
        $result = json_encode($serviceAPI->isUser($email, $pass));
        echo $result;
        break;
    case 2:
        $result = json_encode($serviceAPI->getGenders());
        echo $result;
        break;
    case 3:
        $result = json_encode($serviceAPI->getCountries());
        echo $result;
        break;
    case 4:
    	$name = utf8_decode($_POST["name"]);
    	$middleName = utf8_decode($_POST["middleName"]);
    	$lastName = utf8_decode($_POST["lastName"]);
    	$secondLastName = utf8_decode($_POST["secondLastName"]);
    	$gender = $_POST["gender"];
    	$country = $_POST["country"];
    	$birthday = $_POST["birthday"];
    	$email = $_POST["email"];
    	$password = $_POST["password"];
    	$image = $_FILES["userPicture"];
    	$description = utf8_decode($_POST["description"]);
        $result = json_encode($serviceAPI->newUser($email, $password, $name, 
        										   $middleName, $lastName, $secondLastName,
        										   $gender, $country, $description, $birthday, $image));
        echo $result;
        break;
    case 5:
        $userId = $_COOKIE["id"];
        $result = json_encode($serviceAPI->getUserImage($userId));
        echo $result;
        break;
}

?>