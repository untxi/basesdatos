<?php

require_once 'vendor/autoload.php';

use GraphAware\Neo4j\Client\ClientBuilder;

class LoginRegisterAPI{

	private $mysql;
	private $mongodb;
	private $neo4j;
	private $imageBucket;
	private $jsonData;

	//Constructor de la clase. Inicia conexiones
	public function __construct(){
		$this->mysql = new mysqli('localhost', 'socialnetwork', 'social123', 'userPostDB','3306');
		$this->mongodb = new \MongoDB\Driver\Manager("mongodb://localhost:27017");
		$this->neo4j = ClientBuilder::create()->addConnection('default', 'http://neo4j:neo123@localhost:7474')->build();
		$this->imageBucket = new \MongoDB\GridFS\Bucket($this->mongodb, "images");
		$this->jsonData = array();
	}

	//Destructor de la clase, finaliza la conexión con mysql.
	public function __destruct(){
		//MongoDB, Neo4J y Cassandra se cierran automáticamente
		$this->mysql->close();	
	}


	//Necesario si en un mismo método se ejecutan varios queries de MySQL
	function prepareNextMysqlQuery($query){
		$query->close();
		$this->mysql->next_result();
	}

	//Obtener una imagen desde mongo y retornar el string del src de HTML
	function getImageFromMongo($imageId){
		//Se convierte el string del Id a un objeto ID de Mongo
		$imageMongoId = new MongoDB\BSON\ObjectId($imageId);

		//Se obtiene la imagen
		$path = tempnam(sys_get_temp_dir(), "");
		$out = fopen($path, 'wb');
		$this->imageBucket->downloadToStream($imageMongoId, $out);
		$type = pathinfo($path, PATHINFO_EXTENSION);
		$data = file_get_contents($path);

		//Se convierte la imagen a base 64.
		$imageBase64 = 'data:image/' . $type . ';base64,' . base64_encode($data).'';

		return $imageBase64;
	}

	//MÉTODOS ASOCIADOS AL INICIO DE SESIÓN Y AL REGISTRO
	function getGenders(){
		$gendersQuery= $this->mysql->query("CALL getGenders()");
		$this->jsonData["genders"] = array();

		while($row = $gendersQuery->fetch_array()){
			$gender = array();
			$gender["id"] = $row["genderId"];
			$gender["gender"] = utf8_encode($row["gender"]);
    		array_push($this->jsonData["genders"], $gender);
        }
        $this->prepareNextMysqlQuery($gendersQuery);
        return $this->jsonData;
	}


	function getCountries(){
		$countriesQuery= $this->mysql->query("CALL getCountries()");
		$this->jsonData["countries"] = array();

		while($row = $countriesQuery->fetch_array()){
			$country = array();
			$country["id"] = $row["countryId"];
			$country["country"] = utf8_encode($row["Country"]);
    		array_push($this->jsonData["countries"], $country);
        }
        $this->prepareNextMysqlQuery($countriesQuery);
        return $this->jsonData;
	}

	function getUserImage($pUserId){
		$query= $this->mysql->query("CALL getUserImageId('$pUserId')");
		$userImageId = $query->fetch_row()[0];
		$imageString = $this->getImageFromMongo($userImageId);
		$this->jsonData["image"] = $imageString;
		return $this->jsonData;
	}


	function isUser($pEmail, $pPassword){

		// Revisamos la contraseña, si el resultado no es mayor que 0, nos morimos
		$checkPass = $this->mysql->query("CALL correctPassword('$pEmail', '$pPassword')");
               
            if ($checkPass->fetch_row()[0] > 0) {
            		//Se liberan recursos del query anterior
            		$this->prepareNextMysqlQuery($checkPass);

                    // Generamos una sesion para el usuario
                    // Esta sesion le permite al usuario poder hacer cambios en las bases de datos
                    // Por ejemplo, subir un post, mandar un mensaje a otra persona, seguir a una persona, etc.
                    $session = bin2hex(openssl_random_pseudo_bytes(15));
                    
                    
                    // Hay que guardarla en la base de datos
                    $sessionQuery = $this->mysql->query("CALL setSession('$pEmail', '$session')");

                    if (!$sessionQuery) {
                    	$this->jsonData['RETURN_CODE'] = 'CANT_SET_SESSION';
                    } else {
                        // Tenemos que traernos el nombre completo del usuario
                        $userData = $this->mysql->query("CALL getUserData('$pEmail')");                   
                        if (!$userData) {
							$this->jsonData['RETURN_CODE'] = 'CANT_GET_DATA';
						} else {
                            // Y ponemos los datos relevantes del usuario en los cookies
                            // Esta función solo debería devolver una fila
                            $row = $userData->fetch_array();                                                   
                            setcookie('id', $pEmail, 0, '/');
                            setcookie('name', utf8_encode($row["name"]), 0, '/');
                            setcookie('secondName', utf8_encode($row["secondName"]), 0, '/');
                            setcookie('lastName', utf8_encode($row["lastName"]), 0, '/');
                            setcookie('secondLastName', utf8_encode($row["secondLastName"]), 0, '/');
                            setcookie('session', $session, 0, '/');
                            
                            $this->jsonData['RETURN_CODE'] = 'OK';
                        
                        }
                    }

			} else {
	            $this->jsonData['RETURN_CODE'] = 'WRONG_PASS';
			}
		
		return $this->jsonData;
	}


	function newUser($pEmail, $pPassword, $pName, $pSecondName, $pLastName, $pSecondLastName,
		$pGender, $pCountry, $pDescription, $pBirthdate, $image){

		$checkUser = $this->mysql->query("CALL existUser('$pEmail')");
		
		if ($checkUser->fetch_row()[0] == 1){
			$this->jsonData["RETURN_CODE"] = "EMAIL_TAKEN";
			return $this->jsonData;
		} else {
			$this->prepareNextMysqlQuery($checkUser);

			//Se inserta la imagen en MongoDB
			$myFile = fopen($image["tmp_name"], 'rb');
			$imageId = $this->imageBucket->uploadFromStream($image["tmp_name"], $myFile);
			
			//Se encripta la contraseña
			//$pPassword = password_hash($pPassword, PASSWORD_BCRYPT);

			$pDescription = $this->mysql->real_escape_string($pDescription);

			//Se guardan los datos del nuevo usuario en MySQL
			$result = $this->mysql->query("CALL registerUser('$pEmail', '$pPassword', null, '$pName', '$pSecondName', '$pLastName','$pSecondLastName', $pGender, $pCountry, '$pDescription',STR_TO_DATE('$pBirthdate', '%m/%d/%Y'), '$imageId')");

			//Se crea el nodo en Neo4J
			$query = "CREATE (:User{id:".'\''.$pEmail.'\''."})";
			$result = $this->neo4j->run($query);
		}

		return $this->jsonData;
	}
}

?>