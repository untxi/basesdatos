<?php

require_once 'vendor/autoload.php';

use GraphAware\Neo4j\Client\ClientBuilder;

class ProfileAPI{

	private $mysql;
	private $mongodb;
	private $neo4j;
	private $imageBucket;
	private $jsonData;

	//Constructor de la clase. Inicia conexiones
	public function __construct(){
		$this->mysql = new mysqli('localhost', 'socialnetwork', 'social123', 'userPostDB','3306');
		$this->mongodb = new \MongoDB\Driver\Manager("mongodb://localhost:27017");
		$this->neo4j = ClientBuilder::create()->addConnection('default', 'http://neo4j:neo123@localhost:7474')->build();
		$this->imageBucket = new \MongoDB\GridFS\Bucket($this->mongodb, "images");
		$this->jsonData = array();
	}

	//Destructor de la clase, finaliza la conexión con mysql.
	public function __destruct(){
		//MongoDB, Neo4J y Cassandra se cierran automáticamente
		$this->mysql->close();	
	}


	//Necesario si en un mismo método se ejecutan varios queries de MySQL
	function prepareNextMysqlQuery($query){
		$query->close();
		$this->mysql->next_result();
	}

	//Obtener una imagen desde mongo y retornar el string del src de HTML
	function getImageFromMongo($imageId){
		//Se convierte el string del Id a un objeto ID de Mongo
		$imageMongoId = new MongoDB\BSON\ObjectId($imageId);

		//Se obtiene la imagen
		$path = tempnam(sys_get_temp_dir(), "");
		$out = fopen($path, 'wb');
		$this->imageBucket->downloadToStream($imageMongoId, $out);
		$type = pathinfo($path, PATHINFO_EXTENSION);
		$data = file_get_contents($path);

		//Se convierte la imagen a base 64.
		$imageBase64 = 'data:image/' . $type . ';base64,' . base64_encode($data).'';

		return $imageBase64;
	}


	function getUserProfile($userId){
		$userInfo = $this->mysql->query("CALL getUserProfile('$userId')");

		$userInfoArray = $userInfo->fetch_array();

		$this->jsonData["fullName"] = utf8_encode($userInfoArray["fullName"]);
		$this->jsonData["userImage"] = $this->getImageFromMongo($userInfoArray["imageId"]);
		$this->jsonData["gender"] = $userInfoArray["gender"];
		$this->jsonData["country"] = utf8_encode($userInfoArray["country"]);
		$this->jsonData["description"] = utf8_encode($userInfoArray["description"]);
		$birthdate = $time = strtotime($userInfoArray["birthdate"]);
		$birthdate = date("d/m/y", $time);
		$this->jsonData["birthdate"] = $birthdate;
		$this->jsonData["postsCount"] = $userInfoArray["posts"];

		$this->prepareNextMysqlQuery($userInfo);

		return $this->jsonData;
	}




	function getMostRecentPostDatetime(){
		$latestPostQuery = $this->mysql->query("CALL getMostRecentPostDatetime()");
		$latestPost = $latestPostQuery->fetch_row()[0];
		$this->prepareNextMysqlQuery($latestPostQuery);
		$this->jsonData["latestPost"] = $latestPost;
		return $this->jsonData;
	}

	function getPosts($pUserId){
		//Se hace el string del query para Neo4J.
		$query = "MATCH (:User{id:".'\''.$pUserId.'\''."})-[:FOLLOWS]->(following) RETURN following.id";

		//Se ejecuta el query en neo4j
		$result = $this->neo4j->run($query);

		//Se obtienen todos los resultados del query en un objeto Result de Neo4J
		$result = $result->getRecords();

		if (count($result) == 0){
			$this->jsonData["RETURN_CODE"] = "NO_FOLLOWING";
			return $this->jsonData;
		}


		//Se obtiene la fecha del post más reciente
		$latestPostQuery = $this->mysql->query("CALL getMostRecentPostDatetime()");
		$latestPost = $latestPostQuery->fetch_row()[0];
		$this->prepareNextMysqlQuery($latestPostQuery);

		$this->jsonData["latestPost"] = $latestPost;

		$usersString = "";

		//Se itera sobre cada resultado (cada follower) y se va agregando al Json
		foreach ($result as $res) {

			//Se obtiene el id del follower desde el resultado de Neo4J
			$followingId = $res->value("following.id");

			$usersString = '\''.$followingId.'\','.$usersString;
		}

		$usersString = addslashes($usersString);
		$usersString = rtrim($usersString, ",");


		//Se obtienen los posts de quien se sigue
		$getFollowingPosts = $this->mysql->query("CALL getUserPosts('$usersString', 2)");

		//echo $getFollowingPosts->fetch_array()["fullName"];
		$this->jsonData["posts"] = array();


		//Se itera sobre los posts del usuario actual que se sigue
		while ($post = $getFollowingPosts->fetch_array()) {
			$postArray = array();
			$postType = "";
			$postUserName = utf8_encode($post["fullName"]);
			$postUserImageId = $this->getImageFromMongo($post["imageId"]);
	      	$postText = utf8_encode($post["text"]);
			$postImage = $post["image"];
			$postVideo = $post["video"];
			$postDateTime = $post["datetime"];

			$postArray["userName"] = $postUserName;
			$postArray["userImage"] = $postUserImageId;

			if($postImage != ""){
				$postImage = $this->getImageFromMongo($postImage);					
			}

			if($postVideo != ""){
				$postVideo = $this->getVideoFromMongo($postVideo);
			}

			if ($postText != "" && $postImage == "" && $postVideo == ""){
				$postType = "ONLY_TEXT";
				$postArray["type"] = $postType;
				$postArray["text"] = $postText;
				$postArray["datetime"] = $postDateTime;
			} else if ($postText != "" && $postImage != "" && $postVideo == ""){
				$postType = "TEXT_IMAGE";
				$postArray["type"] = $postType;
				$postArray["text"] = $postText;
				$postArray["image"] = $postImage;
				$postArray["datetime"] = $postDateTime;
			} else if ($postText != "" && $postImage == "" && $postVideo != ""){
				$postType = "TEXT_VIDEO";
				$postArray["type"] = $postType;
				$postArray["text"] = $postText;
				$postArray["video"] = $postVideo;
				$postArray["datetime"] = $postDateTime;
			} else if ($postText != "" && $postImage != "" && $postVideo != ""){
				$postType = "TEXT_IMAGE_VIDEO";
				$postArray["type"] = $postType;
				$postArray["text"] = $postText;
				$postArray["image"] = $postImage;
				$postArray["video"] = $postVideo;
				$postArray["datetime"] = $postDateTime;
			} else if ($postText == "" && $postImage != "" && $postVideo == ""){
				$postType = "ONLY_IMAGE";
				$postArray["type"] = $postType;
				$postArray["image"] = $postImage;
				$postArray["datetime"] = $postDateTime;
			} else if ($postText == "" && $postImage != "" && $postVideo != ""){
				$postType = "IMAGE_VIDEO";
				$postArray["type"] = $postType;
				$postArray["image"] = $postImage;
				$postArray["video"] = $postVideo;
				$postArray["datetime"] = $postDateTime;
			} else if ($postText == "" && $postImage == "" && $postVideo != ""){
				$postType = "ONLY_VIDEO";
				$postArray["type"] = $postType;
				$postArray["video"] = $postVideo;
				$postArray["datetime"] = $postDateTime;
			}
			array_push($this->jsonData["posts"], $postArray);
    	}
	    return $this->jsonData;
	}
	

	//MÉTODOS ASOCIADOS A SEGUIDORES
	function searchUsers($actualUserId,$searchWord){

		$getUsersQuery = $this->mysql->query("CALL searchUsers('$actualUserId','$searchWord')");


		//Se cuentan los seguidores del usuario
		$this->jsonData["totalUsers"] = $getUsersQuery->num_rows;

		//Se crea un contador de género masculino
		$this->jsonData["totalMales"] = 0;

		//Se crea un contador de género femenino
		$this->jsonData["totalFemales"] = 0;

		if ($getUsersQuery->num_rows == 0){
			return $this->jsonData;
		}

		//Se crea un key "followers" que es un array de followers.
		$this->jsonData["users"] = array();

		//Se itera sobre cada resultado (cada follower) y se va agregando al Json
		while ($user = $getUsersQuery->fetch_array()) {
			$array = array();

			//Obtenemos la información del follower
			$userName = $user['fullName'];
			$userId = $user["email"];
			$userImageId = $user['imageId'];
			$userGender = $user['gender'];

			//Aumentamos el contador de géneros de acuerdo al género de cada follower
			if ($userGender == "Male"){
				$this->jsonData["totalMales"]++;
			} else {
				$this->jsonData["totalFemales"]++;
			}

			//Obtenemos la imagen del follower
			$imageStr = $this->getImageFromMongo($userImageId);

			//Se verifica si el usuario ya sigue a quien decidió seguir
			$countMatches = "MATCH (u1:User{id:".'\''.$actualUserId.'\''."})-[r:FOLLOWS]->(u2:User{id:".'\''.$userId.'\''."}) RETURN count(r) AS count";

			//Finalmente se ejecuta el query
			$count = $this->neo4j->run($countMatches);
			
			if ($count->getRecord()->value("count") > 0){
				$array["FOLLOWING"] = "TRUE";
			} else {
				$array["FOLLOWING"] = "FALSE";
			}
				
			//Agregamos los datos del follower al array y luego al json
			$array["id"] = $userId;
			$array["name"] = utf8_encode($userName);
			$array["picture"] = $imageStr;
			array_push($this->jsonData["users"], $array);
		}
		$this->prepareNextMysqlQuery($getUsersQuery);
		return $this->jsonData;
	}


	function followUser($actualUserId, $userToFollowId){

		//Se verifica si el usuario ya sigue a quien decidió seguir
		$countMatches = "MATCH (u1:User{id:".'\''.$actualUserId.'\''."})-[r:FOLLOWS]->(u2:User{id:".'\''.$userToFollowId.'\''."}) RETURN count(r) AS count";

		//Finalmente se ejecuta el query
		$count = $this->neo4j->run($countMatches);
		
		if ($count->getRecord()->value("count") != 0){
			$unfollowQuery = "MATCH (u1:User{id:".'\''.$actualUserId.'\''."})-[r:FOLLOWS]->(u2:User{id:".'\''.$userToFollowId.'\''."}) DELETE r";
			//Finalmente se ejecuta el query
			$count = $this->neo4j->run($unfollowQuery);
			$this->jsonData["RETURN_CODE"] = "UNFOLLOW";
		} else {
			//Se hace el string del query. Se utiliza merge para evitar doble follows.
			$query = "MATCH (u1:User{id:".'\''.$actualUserId.'\''."}), (u2:User{id:".'\''.$userToFollowId.'\''."}) MERGE (u1)-[:FOLLOWS]->(u2)";

			//Finalmente se ejecuta el query
			$result = $this->neo4j->run($query);

			$this->jsonData["RETURN_CODE"] = "FOLLOW";
		}

		return $this->jsonData;
	}



	function getFollowers($userId){

		//Se hace el string del query. Se calculan las relaciones con SIZE.
		$query = "MATCH (:User{id:".'\''.$userId.'\''."})<-[:FOLLOWS]-(followers) RETURN followers.id, SIZE((followers)-[:FOLLOWS]->()) AS followersOfFollower, SIZE(()-[:FOLLOWS]->(followers)) AS followerFollowing";

		//Se ejecuta el query en neo4j
		$result = $this->neo4j->run($query);

		//Se obtienen todos los resultados del query en un objeto Result de Neo4J
		$result = $result->getRecords();

		//Se crea un key "followers" que es un array de followers.
		$this->jsonData["followers"] = array();

		//Se cuentan los seguidores del usuario
		$this->jsonData["totalFollowers"] = count($result);

		//Se crea un contador de género masculino
		$this->jsonData["totalMales"] = 0;

		//Se crea un contador de género femenino
		$this->jsonData["totalFemales"] = 0;

		//Se itera sobre cada resultado (cada follower) y se va agregando al Json
		foreach ($result as $res) {
			$array = array();

			//Se obtiene el id del follower desde el resultado de Neo4J
			$followerId = $res->value("followers.id");

			//Obtenemos la información del follower
			$getFollowerInfo = $this->mysql->query("CALL getFollowerInfo('$followerId')");
			$followerInfo = $getFollowerInfo->fetch_array();
			$followerName = $followerInfo['fullName'];
			$followerImageId = $followerInfo['imageId'];
			$followerGender = $followerInfo['gender'];
			$followerPosts = $followerInfo['posts'];

			//Aumentamos el contador de géneros de acuerdo al género de cada follower
			if ($followerGender == "Male"){
				$this->jsonData["totalMales"]++;
			} else {
				$this->jsonData["totalFemales"]++;
			}

			//Obtenemos la imagen del follower
			$imageStr = $this->getImageFromMongo($followerImageId);
				
			//Agregamos los datos del follower al array y luego al json
			$array["id"] = $followerId;
			$array["name"] = utf8_encode($followerName);
			$array["picture"] = $imageStr;
			$array["posts"] = $followerPosts;
			$array["followers"] = $res->value("followersOfFollower");
			$array["following"] = $res->value("followerFollowing");
			array_push($this->jsonData["followers"], $array);

			$this->prepareNextMysqlQuery($getFollowerInfo);
		}
		return $this->jsonData;
	}


	//Este método es casi igual al anterior; sin embargo, para mejorar contexto se escribe de nuevo.
	function getFollowing($userId){

		//Se hace el string del query. Se calculan las relaciones con SIZE.
		$query = "MATCH (:User{id:".'\''.$userId.'\''."})-[:FOLLOWS]->(following) RETURN following.id, SIZE((following)-[:FOLLOWS]->()) AS followersOfFollowing, SIZE(()-[:FOLLOWS]->(following)) AS followingFollowing";

		//Se ejecuta el query en neo4j
		$result = $this->neo4j->run($query);

		//Se obtienen todos los resultados del query en un objeto Result de Neo4J
		$result = $result->getRecords();

		//Se crea un key "following" que es un array de usuarios a los que sigue el usuario actual.
		$this->jsonData["following"] = array();

		//Se cuentan los seguidores del usuario
		$this->jsonData["totalFollowing"] = count($result);

		//Se crea un contador de género masculino
		$this->jsonData["totalMales"] = 0;

		//Se crea un contador de género femenino
		$this->jsonData["totalFemales"] = 0;

		//Se itera sobre cada resultado (cada follower) y se va agregando al Json
		foreach ($result as $res) {
			$array = array();

			//Se obtiene el id del follower desde el resultado de Neo4J
			$followingId = $res->value("following.id");

			//Obtenemos la información del follower
			$getFollowingInfo = $this->mysql->query("CALL getFollowerInfo('$followingId')");
			$followingInfo = $getFollowingInfo->fetch_array();
			$followingName = $followingInfo['fullName'];
			$followingImageId = $followingInfo['imageId'];
			$followingGender = $followingInfo['gender'];
			$followingPosts = $followingInfo['posts'];

			//Aumentamos el contador de géneros de acuerdo al género de cada follower
			if ($followingGender == "Male"){
				$this->jsonData["totalMales"]++;
			} else {
				$this->jsonData["totalFemales"]++;
			}

			//Obtenemos la imagen del follower
			$imageStr = $this->getImageFromMongo($followingImageId);
				
			//Agregamos los datos del follower al array y luego al json
			$array["id"] = $followingId;
			$array["name"] = utf8_encode($followingName);
			$array["picture"] = $imageStr;
			$array["posts"] = $followingPosts;
			$array["followers"] = $res->value("followersOfFollowing");
			$array["following"] = $res->value("followingFollowing");
			array_push($this->jsonData["following"], $array);

			$this->prepareNextMysqlQuery($getFollowingInfo);
		}
		return $this->jsonData;
	}
}

?>