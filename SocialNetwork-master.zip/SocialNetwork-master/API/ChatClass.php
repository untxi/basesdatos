<?php

require_once 'vendor/autoload.php';

use GraphAware\Neo4j\Client\ClientBuilder;

class ChatAPI {

	private $mysql;
	private $neo4j;
	private $cassandra;
	
	private $jsonData;

	//Constructor de la clase. Inicia conexiones
	public function __construct(){
		$this->mysql = new mysqli('localhost', 'socialnetwork', 'social123', 'userPostDB','3306');
		$this->neo4j = ClientBuilder::create()->addConnection('default', 'http://neo4j:neo123@localhost:7474')->build();
		$this->cassandra = Cassandra::cluster()->withCredentials('socialnet','proyectobases')->build()->connect('socialnet');
		
		$this->jsonData = array();
	}

	//Destructor de la clase, finaliza la conexión con mysql.
	public function __destruct(){
		//MongoDB, Neo4J y Cassandra se cierran automáticamente
		$this->mysql->close();	
	}


	//Necesario si en un mismo método se ejecutan varios queries de MySQL
	function prepareNextMysqlQuery($query){
		$query->close();
		$this->mysql->next_result();
	}

	function getConversations($userID) {
            $conversationsSender = $this->cassandra->execute(new Cassandra\SimpleStatement(
		'SELECT idConversacion, idReceptor FROM conversacion WHERE idEmisor = ?'), 
		new Cassandra\ExecutionOptions(array('arguments' => array($userID))));

            $conversationsReceiver = $this->cassandra->execute(new Cassandra\SimpleStatement(
                    'SELECT idConversacion, idEmisor FROM conversacion WHERE idReceptor = ?'), 
                    new Cassandra\ExecutionOptions(array('arguments' => array($userID))));
                    
            // Una vez que se tengan las conversaciones, hay que traerse los nombres de usuario
            foreach ($conversationsSender as $conv) {
                $getUserName = $this->mysql->query("CALL getFullName('" . $conv['idreceptor'] . "')");
                
                $convData = array();
                $convData['convID'] = $conv['idconversacion']->uuid();
                $convData['userName'] = utf8_encode($getUserName->fetch_row()[0]);
                
                $this->jsonData[] = $convData;
                
                $this->prepareNextMysqlQuery($getUserName);
            }
            
            
            
            foreach ($conversationsReceiver as $conv) {
                $getUserName = $this->mysql->query("CALL getFullName('" . $conv['idemisor'] . "')");
                
                $convData = array();
                $convData['convID'] = $conv['idconversacion']->uuid();
                $convData['userName'] = utf8_encode($getUserName->fetch_row()[0]);
                
                $this->jsonData[] = $convData;
                
                $this->prepareNextMysqlQuery($getUserName);
            }
            
            return $this->jsonData;
	}
	
	
	function updateMessage($conv) {
            $this->cassandra->execute(new Cassandra\SimpleStatement(
                'UPDATE mensaje SET visto = True WHERE idconversacion = ? AND enviado = ? AND idemisor = ? AND mensaje = ?'), 
                new Cassandra\ExecutionOptions(array('arguments' => array($conv["idconversacion"], $conv["enviado"], $conv["idemisor"], $conv["mensaje"]))));
	}
	
	
	function getMessages($userID, $convID) {
            $convMessages = $this->cassandra->execute(new Cassandra\SimpleStatement(
            'SELECT idconversacion, enviado, idemisor, mensaje FROM mensaje WHERE idconversacion = ? ORDER BY enviado;'), 
            new Cassandra\ExecutionOptions(array('arguments' => array($convID))));
            
            foreach($convMessages as $conv) {
                
                $msgData = array();
                
                $getUserName = $this->mysql->query("CALL getFullName('" . $conv['idemisor'] . "')");
                
                if ($conv["idemisor"] != $userID) {
                    $msgData["otherUser"] = true;
                    $this->updateMessage($conv);
                    
                } else {
                    $msgData["otherUser"] = false;
                }
                
                $msgData["author"] = utf8_encode($getUserName->fetch_row()[0]);
                $msgData["message"] = $conv["mensaje"];
                
                $this->jsonData[] = $msgData;
                
                $this->prepareNextMysqlQuery($getUserName);
            }
                
            return $this->jsonData;
                
        }
        
        function sendMessage($userID, $convID, $message) {
            $convMessages = $this->cassandra->execute(new Cassandra\SimpleStatement(
                "INSERT INTO mensaje(idconversacion, idemisor, enviado, mensaje, visto) VALUES (?, ?, toTimestamp(now()), ?, false)"), 
                new Cassandra\ExecutionOptions(array('arguments' => array($convID, $userID, $message))));
            
            $getUserName = $this->mysql->query("CALL getFullName('" . $userID . "')");
            
            $this->jsonData["author"] = utf8_encode($getUserName->fetch_row()[0]);
            $this->jsonData["message"] = $message;
            
            $this->prepareNextMysqlQuery($getUserName);
            return $this->jsonData;
                
        }
        
        function sendMessageTo($userID, $receiverID, $message) {
            // Hay que revisar si existe la conversacion, por ambos lados
            // Revisamos si existe si el usuario actual es el emisor
            $existsAsSender = $this->cassandra->execute(new Cassandra\SimpleStatement(
                "SELECT * FROM conversacion WHERE idemisor = ? AND idreceptor = ? ALLOW FILTERING"), 
                new Cassandra\ExecutionOptions(array('arguments' => array($userID, $receiverID))));
            
            $existsAsReceiver = $this->cassandra->execute(new Cassandra\SimpleStatement(
                "SELECT * FROM conversacion WHERE idemisor = ? AND idreceptor = ? ALLOW FILTERING"), 
                new Cassandra\ExecutionOptions(array('arguments' => array($receiverID, $userID))));
                        
            $convID = null;
            $newConversation = false;
            
            // Si viene un resultado, sacamos el ID de la conversacion
            // Caso contrario, creamos un nuevo ID para la conversacion
            if ($existsAsSender->count() != 0) {
                $convID = $existsAsSender[0]['idconversacion'];
            } else {
                if ($existsAsReceiver->count() != 0) {
                    $convID = $existsAsReceiver[0]['idconversacion'];
                } else {
                    $convID = new Cassandra\Uuid();
                    $newConversation = true;
                }
            }
            
            
            
            // Si en efecto es una nueva conversacion, tenemos que crear la conversacion en la base
            if ($newConversation == true) {
                $this->cassandra->execute(new Cassandra\SimpleStatement(
                    "INSERT INTO conversacion(idconversacion, idemisor, idreceptor) VALUES(?, ?, ?)"), 
                    new Cassandra\ExecutionOptions(array('arguments' => array($convID, $userID, $receiverID))));
            }
            
            // Hacemos uso de la funcion sendMessage previamente creada
            $result = $this->sendMessage($userID, $convID, $message);
            
            $result['newConv'] = $newConversation;
            $result['convID'] = $convID->uuid();
            
            // Ocupamos el nombre de quien recibe los datos
            $getUserName = $this->mysql->query("CALL getFullName('" . $receiverID . "')");
            $result['receiverName'] = utf8_encode($getUserName->fetch_row()[0]);
            
            $this->prepareNextMysqlQuery($getUserName);
            
            return $result;
            
            
        }
        
        // Adaptado del original en FollowersClass.php, solo devuelve el ID y el nombre completo
        function getUserFollowing($userId){

            //Se hace el string del query. Se calculan las relaciones con SIZE.
            $query = "MATCH (:User{id:".'\''.$userId.'\''."})-[:FOLLOWS]->(following) RETURN following.id";

            //Se ejecuta el query en neo4j
            $result = $this->neo4j->run($query);

            //Se obtienen todos los resultados del query en un objeto Result de Neo4J
            $result = $result->getRecords();

            //Se itera sobre cada resultado (cada follower) y se va agregando al Json
            foreach ($result as $res) {
                $usrData = array();

                //Se obtiene el id del follower desde el resultado de Neo4J
                $followingId = $res->value("following.id");

                //Obtenemos la información del follower (nombre)
                $getUserName = $this->mysql->query("CALL getFullName('" . $followingId . "')");


                $usrData["userID"] = $followingId;
                $usrData["userName"] = utf8_encode($getUserName->fetch_row()[0]);
                
                $this->jsonData[] = $usrData;
                
                $this->prepareNextMysqlQuery($getUserName);
            }
            return $this->jsonData;
        }
        
        
        // Obtenemos el numero total de conversaciones
        function getConvNumber($userId) {
            $conversationsSender = $this->cassandra->execute(new Cassandra\SimpleStatement(
		'SELECT COUNT(idconversacion) AS totalconv FROM conversacion WHERE idemisor = ?'), 
		new Cassandra\ExecutionOptions(array('arguments' => array($userId))));

            $conversationsReceiver = $this->cassandra->execute(new Cassandra\SimpleStatement(
                'SELECT COUNT(idconversacion) AS totalconv FROM conversacion WHERE idreceptor = ?'), 
                new Cassandra\ExecutionOptions(array('arguments' => array($userId))));
                
            $this->jsonData["totalConv"] = $conversationsSender[0]["totalconv"];
            $this->jsonData["totalConv"] += $conversationsReceiver[0]["totalconv"];
            
            return $this->jsonData;
        }
        
        function getUnseenMessagesNumber($userID, $convID) {
            // Tenemos que ver si la otra parte es el receptor o el emisor
            $conversationsReceiver = $this->cassandra->execute(new Cassandra\SimpleStatement(
		'SELECT idreceptor FROM conversacion WHERE idconversacion = ? and idemisor = ?'), 
		new Cassandra\ExecutionOptions(array('arguments' => array($convID, $userID))));
		
            
            $conversationsSender = $this->cassandra->execute(new Cassandra\SimpleStatement(
		'SELECT idemisor FROM conversacion WHERE idconversacion = ? and idreceptor = ?'), 
		new Cassandra\ExecutionOptions(array('arguments' => array($convID, $userID))));
            
            $otherUserID = null;
            
            if ($conversationsReceiver->count() != 0) {
                $otherUserID = $conversationsReceiver[0]["idreceptor"];
            } else {
                if ($conversationsSender->count() != 0) {
                    $otherUserID = $conversationsSender[0]["idemisor"];
                }
            }
            
            $totalConversations = $this->cassandra->execute(new Cassandra\SimpleStatement(
		'SELECT COUNT(idconversacion) AS totalmsgs FROM mensaje WHERE idconversacion = ? AND idemisor = ? AND visto = False ALLOW FILTERING'), 
		new Cassandra\ExecutionOptions(array('arguments' => array($convID, $otherUserID))));
		
            $this->jsonData["totalMessages"] = $totalConversations[0]["totalmsgs"]->value();
            $this->jsonData["otherUserID"] = $otherUserID;
            
            return $this->jsonData;
        }
        
        function getUnseenMessages($userID, $convID, $otherUserID) {
            $convMessages = $this->cassandra->execute(new Cassandra\SimpleStatement(
                'SELECT idconversacion, enviado, idemisor, mensaje FROM mensaje WHERE idconversacion = ? and idemisor = ? AND visto = False ALLOW FILTERING;'), 
                new Cassandra\ExecutionOptions(array('arguments' => array($convID, $otherUserID))));
            
            foreach($convMessages as $conv) {
                $msgData = array();
                
                $getUserName = $this->mysql->query("CALL getFullName('" . $conv['idemisor'] . "')");
                
                if ($conv["idemisor"] != $userID) {
                    $msgData["otherUser"] = true;
                    $this->updateMessage($conv);
                    
                } else {
                    $msgData["otherUser"] = false;
                }
                
                $msgData["author"] = utf8_encode($getUserName->fetch_row()[0]);
                $msgData["message"] = $conv["mensaje"];
                
                $this->jsonData[] = $msgData;
                
                $this->prepareNextMysqlQuery($getUserName);
            }
                
            return $this->jsonData;
                
        }
}

?>