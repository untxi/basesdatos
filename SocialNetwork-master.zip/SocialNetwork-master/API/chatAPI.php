<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once('ChatClass.php');

$serviceAPI = new ChatAPI();

$action = $_POST["action"];


switch ($action) {
    
    case "getConversations":
        $userId = $_COOKIE["id"];
        $result = json_encode($serviceAPI->getConversations($userId));
        echo $result;
        break;
        
    case "getMessages":
        $userId = $_COOKIE["id"];
        $conversationID = new Cassandra\Uuid($_POST["convID"]);
        $result = json_encode($serviceAPI->getMessages($userId, $conversationID));
        echo $result;
        break;
    
    case "sendMessage":
        $userId = $_COOKIE["id"];
        $conversationID = new Cassandra\Uuid($_POST["convID"]);
        $message = $_POST["msg"];
        $result = json_encode($serviceAPI->sendMessage($userId, $conversationID, $message));
        echo $result;
        break;
    
    case "getUserFollowing":
        $userId = $_COOKIE["id"];
        $result = json_encode($serviceAPI->getUserFollowing($userId));
        echo $result;
        break;
        
    case "sendMessageTo":
        $userId = $_COOKIE["id"];
        $receiverID = $_POST["receiver"];
        $message = $_POST["msg"];
        $result = json_encode($serviceAPI->sendMessageTo($userId, $receiverID, $message));
        echo $result;
        break;
        
    case "getConvNumber":
        $userId = $_COOKIE["id"];
        $result = json_encode($serviceAPI->getConvNumber($userId));
        echo $result;
        break;
        
    case "getUnseenMessagesNumber":
        $userId = $_COOKIE["id"];
        $conversationID = new Cassandra\Uuid($_POST["convID"]);
        $result = json_encode($serviceAPI->getUnseenMessagesNumber($userId, $conversationID));
        echo $result;
        break;
    
    case "getUnseenMessages":
        $userId = $_COOKIE["id"];
        $conversationID = new Cassandra\Uuid($_POST["convID"]);
        $otherUserID = $_POST["otherUserID"];
        $result = json_encode($serviceAPI->getUnseenMessages($userId, $conversationID, $otherUserID));
        echo $result;
        break;
    
    
    
}

?>