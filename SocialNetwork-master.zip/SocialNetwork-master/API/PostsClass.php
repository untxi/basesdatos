<?php

require_once 'vendor/autoload.php';

use GraphAware\Neo4j\Client\ClientBuilder;

class PostAPI{

	private $mysql;
	private $mysqlLikes;
	private $mongodb;
	private $neo4j;
	private $imageBucket;
	private $videoBucket;
	private $jsonData;

	//Constructor de la clase. Inicia conexiones
	public function __construct(){
		$this->mysql = new mysqli('localhost', 'socialnetwork', 'social123', 'userPostDB','3306');
		$this->mysqlLikes = new mysqli('localhost', 'likes', 'likes123', 'LikeDB','3306');
		$this->mongodb = new \MongoDB\Driver\Manager("mongodb://localhost:27017");
		$this->neo4j = ClientBuilder::create()->addConnection('default', 'http://neo4j:neo123@localhost:7474')->build();
		$this->imageBucket = new \MongoDB\GridFS\Bucket($this->mongodb, "images");
		$this->videoBucket = new \MongoDB\GridFS\Bucket($this->mongodb, "videos");
		$this->jsonData = array();
	}

	//Destructor de la clase, finaliza la conexión con mysql.
	public function __destruct(){
		//MongoDB, Neo4J y Cassandra se cierran automáticamente
		$this->mysql->close();	
	}


	//Necesario si en un mismo método se ejecutan varios queries de MySQL
	function prepareNextMysqlQuery($query, $conn){
		$query->close();
		$conn->next_result();
	}

	//Obtener una imagen desde mongo y retornar el string del src de HTML
	function getImageFromMongo($imageId){
		//Se convierte el string del Id a un objeto ID de Mongo
		$imageMongoId = new MongoDB\BSON\ObjectId($imageId);

		//Se obtiene la imagen
		$path = tempnam(sys_get_temp_dir(), "");
		$out = fopen($path, 'wb');
		$this->imageBucket->downloadToStream($imageMongoId, $out);
		$type = pathinfo($path, PATHINFO_EXTENSION);
		$data = file_get_contents($path);

		//Se convierte la imagen a base 64.
		$imageBase64 = 'data:image/' . $type . ';base64,' . base64_encode($data).'';

		return $imageBase64;
	}


	//Obtener un video desde mongo y retornar el string del src de HTML
	function getVideoFromMongo($videoId){
		//Convertimos el id del video a un objeto ID de Mongo
		$videoMongoId = new MongoDB\BSON\ObjectId($videoId);

		//Se obtiene el video del post
		$path = tempnam(sys_get_temp_dir(), "");
		$out = fopen($path, 'wb');
		$this->videoBucket->downloadToStream($videoMongoId, $out);
		$data = file_get_contents($path);

		//Se convierte la imagen a base 64.
		$videoBase64 = '"data:video/mp4;base64,' . base64_encode($data).'"';

		return $videoBase64;
	}


	//MÉTODO ASOCIADO A LOS POSTS.
	function createPost($pUserId, $pPostText, $pImage, $pVideo){
		$imageId = null;
		$videoId = null;

		if ($pImage != "null"){
			if (substr(mime_content_type($pImage["tmp_name"]), 0,5) != "image"){
				$this->jsonData["RETURN_CODE"] = "INVALID_IMAGE";
				return $this->jsonData;
			}
			$myFile = fopen($pImage["tmp_name"], 'rb');
			$imageId = $this->imageBucket->uploadFromStream($pImage["tmp_name"], $myFile);
		}
		if ($pVideo != "null"){
			if (mime_content_type($pVideo["tmp_name"]) != "video/mp4"){
				$this->jsonData["RETURN_CODE"] = "INVALID_VIDEO";
				return $this->jsonData;
			}
			$myFile = fopen($pVideo["tmp_name"], 'rb');
			$videoId = $this->videoBucket->uploadFromStream($pVideo["tmp_name"], $myFile);
		}

		$pPostText = utf8_decode($pPostText); 
		
		$pPostText = $this->mysql->real_escape_string($pPostText);

		$postQuery = $this->mysql->query("CALL newPost('$pUserId', '$pPostText', '$imageId', '$videoId')");

		if(!$postQuery){
			$this->jsonData["RETURN_CODE"] = "NOT_OK";
		} else {
			$this->jsonData["RETURN_CODE"] = "OK";
		}
		return $this->jsonData;
	}

	function getMostRecentPostDatetime(){
		$latestPostQuery = $this->mysql->query("CALL getMostRecentPostDatetime()");
		$latestPost = $latestPostQuery->fetch_row()[0];
		$this->prepareNextMysqlQuery($latestPostQuery, $this->mysql);
		$this->jsonData["latestPost"] = $latestPost;
		return $this->jsonData;
	}

	function getPosts($pUserId){
		//Se hace el string del query para Neo4J.
		$query = "MATCH (:User{id:".'\''.$pUserId.'\''."})-[:FOLLOWS]->(following) RETURN following.id";

		//Se ejecuta el query en neo4j
		$result = $this->neo4j->run($query);

		//Se obtienen todos los resultados del query en un objeto Result de Neo4J
		$result = $result->getRecords();

		if (count($result) == 0){
			$this->jsonData["RETURN_CODE"] = "NO_FOLLOWING";
			return $this->jsonData;
		}


		//Se obtiene la fecha del post más reciente
		$latestPostQuery = $this->mysql->query("CALL getMostRecentPostDatetime()");
		$latestPost = $latestPostQuery->fetch_row()[0];
		$this->prepareNextMysqlQuery($latestPostQuery, $this->mysql);

		$this->jsonData["latestPost"] = $latestPost;

		$usersString = '\''.$pUserId.'\',';

		//Se itera sobre cada resultado (cada follower) y se va agregando al Json
		foreach ($result as $res) {

			//Se obtiene el id del follower desde el resultado de Neo4J
			$followingId = $res->value("following.id");

			$usersString = '\''.$followingId.'\','.$usersString;
		}

		$usersString = addslashes($usersString);
		$usersString = rtrim($usersString, ",");


		//Se obtienen los posts de quien se sigue
		$getFollowingPosts = $this->mysql->query("CALL getUserPosts('$usersString', 2)", MYSQLI_STORE_RESULT);
		
		$this->jsonData["posts"] = array();


		//Se itera sobre los posts del usuario actual que se sigue
		while ($post = $getFollowingPosts->fetch_array()) {
			$postArray = array();
			$postType = "";
			$postUserName = utf8_encode($post["fullName"]);
			$postUserImageId = $this->getImageFromMongo($post["imageId"]);
	      	$postText = utf8_encode($post["text"]);
			$postImage = $post["image"];
			$postVideo = $post["video"];
			$postDateTime = $post["datetime"];
			$time = strtotime($postDateTime);
			$postDateTime = date("d/m/y g:i A", $time);
			$postId = $post["postId"];
			$postLikesQuery = $this->mysqlLikes->query("CALL postLikesCount('$postId')");
			$postLikes = $postLikesQuery->fetch_row()[0];
			$this->prepareNextMysqlQuery($postLikesQuery, $this->mysqlLikes);

			$postArray["userName"] = $postUserName;
			$postArray["userImage"] = $postUserImageId;

			$userLikesPostQuery = $this->mysqlLikes->query("CALL userLikesPost('$postId', '$pUserId')");

			if($userLikesPostQuery->fetch_row()[0] == 1){
				$postArray["actualUserLikes"] = true;
			} else {
				$postArray["actualUserLikes"] = false;
			}

			$this->prepareNextMysqlQuery($userLikesPostQuery, $this->mysqlLikes);

			if($postImage != ""){
				$postImage = $this->getImageFromMongo($postImage);					
			}

			if($postVideo != ""){
				$postVideo = $this->getVideoFromMongo($postVideo);
			}

			if ($postText != "" && $postImage == "" && $postVideo == ""){
				$postType = "ONLY_TEXT";
				$postArray["type"] = $postType;
				$postArray["text"] = $postText;
				$postArray["datetime"] = $postDateTime;
			} else if ($postText != "" && $postImage != "" && $postVideo == ""){
				$postType = "TEXT_IMAGE";
				$postArray["type"] = $postType;
				$postArray["text"] = $postText;
				$postArray["image"] = $postImage;
				$postArray["datetime"] = $postDateTime;
			} else if ($postText != "" && $postImage == "" && $postVideo != ""){
				$postType = "TEXT_VIDEO";
				$postArray["type"] = $postType;
				$postArray["text"] = $postText;
				$postArray["video"] = $postVideo;
				$postArray["datetime"] = $postDateTime;
			} else if ($postText != "" && $postImage != "" && $postVideo != ""){
				$postType = "TEXT_IMAGE_VIDEO";
				$postArray["type"] = $postType;
				$postArray["text"] = $postText;
				$postArray["image"] = $postImage;
				$postArray["video"] = $postVideo;
				$postArray["datetime"] = $postDateTime;
			} else if ($postText == "" && $postImage != "" && $postVideo == ""){
				$postType = "ONLY_IMAGE";
				$postArray["type"] = $postType;
				$postArray["image"] = $postImage;
				$postArray["datetime"] = $postDateTime;
			} else if ($postText == "" && $postImage != "" && $postVideo != ""){
				$postType = "IMAGE_VIDEO";
				$postArray["type"] = $postType;
				$postArray["image"] = $postImage;
				$postArray["video"] = $postVideo;
				$postArray["datetime"] = $postDateTime;
			} else if ($postText == "" && $postImage == "" && $postVideo != ""){
				$postType = "ONLY_VIDEO";
				$postArray["type"] = $postType;
				$postArray["video"] = $postVideo;
				$postArray["datetime"] = $postDateTime;
			}
			$postArray["postId"] = $postId;
			$postArray["likes"] = $postLikes;
			$postArray["datetime"] = $postDateTime;
			array_push($this->jsonData["posts"], $postArray);
    	}
	    return $this->jsonData;
	}

	function likeOrDislikePost($postId, $userId){
		$userLikesPostQuery = $this->mysqlLikes->query("CALL userLikesPost('$postId', '$userId')");

		$userLikesPost = $userLikesPostQuery->fetch_row()[0];

		$this->prepareNextMysqlQuery($userLikesPostQuery, $this->mysqlLikes);

		if($userLikesPost == 0){
			$query = $this->mysqlLikes->query("CALL addLike('$postId', '$userId')");
			$this->jsonData["postLikes"] = 
			$this->jsonData["RETURN_CODE"] = "LIKED";
		} else {
			$query = $this->mysqlLikes->query("CALL deleteLike('$postId', '$userId')");
			$this->jsonData["RETURN_CODE"] = "DISLIKED";
		}

		$postLikesQuery = $this->mysqlLikes->query("CALL postLikesCount('$postId')");
		$postLikes = $postLikesQuery->fetch_row()[0];
		$this->jsonData["postLikes"] = $postLikes;	
		return $this->jsonData;
	}
}

?>