-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema LikeDB
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema LikeDB
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `LikeDB` DEFAULT CHARACTER SET utf8 ;
USE `LikeDB` ;

-- -----------------------------------------------------
-- Table `LikeDB`.`Like`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `LikeDB`.`Like` (
  `postId` INT NOT NULL COMMENT 'Saves the id of the liked post.',
  `userId` VARCHAR(254) NOT NULL COMMENT 'Saves the id of the user who liked the post',
  PRIMARY KEY (`userId`, `postId`))
COMMENT = 'Table Like saves id of post liked and who gave the like';

USE `LikeDB` ;

-- -----------------------------------------------------
-- procedure addLike
-- -----------------------------------------------------

DELIMITER $$
USE `LikeDB`$$
CREATE PROCEDURE `addLike`(pPost INT, pUser VARCHAR(254))
    COMMENT 'This adds one like to a post.'
BEGIN
	INSERT INTO LikeDB.Like (postId, userId)
    VALUES (pPost, pUser);
    COMMIT;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure deleteLike
-- -----------------------------------------------------

DELIMITER $$
USE `LikeDB`$$
CREATE PROCEDURE `deleteLike`(pPost INT, pUser VARCHAR(254))
    COMMENT 'This delete a like of a post.'
BEGIN
	DELETE FROM LikeDB.Like
    WHERE postId=pPost AND userId=pUser;
    COMMIT;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure postLikesCount
-- -----------------------------------------------------

DELIMITER $$
USE `LikeDB`$$
CREATE PROCEDURE `postLikesCount`(pPost INT)
    COMMENT 'Give how many likes have my post.'
BEGIN
	SELECT COUNT(userId) AS likes
    FROM LikeDB.Like
    WHERE postId=pPost;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure userLikesPost
-- -----------------------------------------------------

DELIMITER $$
USE `LikeDB`$$
CREATE PROCEDURE `userLikesPost`(pPost INT, pUser VARCHAR(254))
COMMENT 'Returns 1 if the user likes the post. 0 Otherwise'
BEGIN
	SELECT COUNT(*) AS userLike
    FROM LikeDB.Like
    WHERE postId = pPost and userId = pUser;
END$$

DELIMITER ;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
