CREATE USER `likes`@`localhost` IDENTIFIED BY 'likes123';
CREATE USER `socialnetwork`@`localhost` IDENTIFIED BY 'social123';
GRANT ALL ON *.* TO 'likes'@'localhost';
GRANT ALL ON *.* TO 'socialnetwork'@'localhost';
