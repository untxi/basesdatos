USE userPostDB;
CALL newGender('Male');
CALL newGender('Female');