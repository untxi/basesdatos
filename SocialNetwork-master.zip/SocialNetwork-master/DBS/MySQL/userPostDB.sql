-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema userPostDB
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema userPostDB
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `userPostDB` DEFAULT CHARACTER SET utf8 ;
USE `userPostDB` ;

-- -----------------------------------------------------
-- Table `userPostDB`.`Country`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `userPostDB`.`Country` (
  `countryId` INT NOT NULL AUTO_INCREMENT,
  `country` VARCHAR(50) CHARACTER SET 'utf8' NOT NULL,
  PRIMARY KEY (`countryId`),
  UNIQUE INDEX `countryId_UNIQUE` (`countryId` ASC))
DEFAULT CHARACTER SET = utf8
COMMENT = 'Table of Countries to associate with users';


-- -----------------------------------------------------
-- Table `userPostDB`.`Gender`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `userPostDB`.`Gender` (
  `genderId` INT NOT NULL AUTO_INCREMENT,
  `gender` VARCHAR(15) NOT NULL,
  PRIMARY KEY (`genderId`),
  UNIQUE INDEX `genderId_UNIQUE` (`genderId` ASC))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COMMENT = 'Table of Genders to associate with users';


-- -----------------------------------------------------
-- Table `userPostDB`.`User`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `userPostDB`.`User` (
  `email` VARCHAR(254) NOT NULL,
  `password` VARCHAR(65) NOT NULL,
  `session` VARCHAR(30) NULL,
  `name` VARCHAR(20) NOT NULL,
  `secondName` VARCHAR(20) NULL,
  `lastName` VARCHAR(20) NOT NULL,
  `secondLastName` VARCHAR(20) NULL,
  `genderId` INT NOT NULL,
  `countryId` INT NOT NULL,
  `description` VARCHAR(350) NULL,
  `birthdate` DATE NOT NULL,
  `imageId` VARCHAR(64) NOT NULL,
  PRIMARY KEY (`email`),
  UNIQUE INDEX `email_UNIQUE` (`email` ASC),
  INDEX `countryFk_idx` (`countryId` ASC),
  INDEX `fk_gender_idx` (`genderId` ASC),
  CONSTRAINT `fk_country`
    FOREIGN KEY (`countryId`)
    REFERENCES `userPostDB`.`Country` (`countryId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_gender`
    FOREIGN KEY (`genderId`)
    REFERENCES `userPostDB`.`Gender` (`genderId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
DEFAULT CHARACTER SET = utf8
COMMENT = 'Table of users and they personal information';


-- -----------------------------------------------------
-- Table `userPostDB`.`Post`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `userPostDB`.`Post` (
  `postId` INT NOT NULL AUTO_INCREMENT,
  `userId` VARCHAR(254) NOT NULL,
  `text` VARCHAR(256) NULL,
  `image` VARCHAR(64) NULL,
  `video` VARCHAR(64) NULL,
  `dateTime` DATETIME NOT NULL DEFAULT now(),
  PRIMARY KEY (`postId`),
  UNIQUE INDEX `postId_UNIQUE` (`postId` ASC),
  INDEX `usuarioFk_idx` (`userId` ASC),
  CONSTRAINT `fk_user`
    FOREIGN KEY (`userId`)
    REFERENCES `userPostDB`.`User` (`email`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
DEFAULT CHARACTER SET = utf8
COMMENT = 'Table of posts done by user';

USE `userPostDB` ;

-- -----------------------------------------------------
-- procedure registerUser
-- -----------------------------------------------------

DELIMITER $$
USE `userPostDB`$$
CREATE PROCEDURE `registerUser`(pEmail VARCHAR(254), pPassword VARCHAR(65), pSession VARCHAR(30), 
	pName VARCHAR(20), pSecondName VARCHAR(20), pLastName VARCHAR(20),pSecondLastName VARCHAR(20), 
    pGender INT, pCountry INT, pDescription VARCHAR(350), pBirthdate DATE, pImageId VARCHAR(64))
    COMMENT 'Create a new user'
BEGIN
	INSERT INTO User (email, password, session, name, secondName, lastName, secondLastName, 
    genderId, countryId, description, birthdate, imageId)
    VALUE (pEmail, PASSWORD(pPassword), pSession, pName, pSecondName, pLastName, 
    pSecondLastName, pGender, pCountry, pDescription, pBirthdate, pImageId);
    COMMIT;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure delUser
-- -----------------------------------------------------

DELIMITER $$
USE `userPostDB`$$
CREATE PROCEDURE `delUser`(pEmail VARCHAR(254))
    COMMENT 'Delete an user from DataBase'
BEGIN
	DELETE FROM User
    WHERE email=pEmail;
    COMMIT;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure getFullName
-- -----------------------------------------------------

DELIMITER $$
USE `userPostDB`$$
CREATE PROCEDURE `getFullName`(pEmail VARCHAR(254))
    COMMENT 'It returns user full name'
BEGIN
	SELECT CONCAT(name, " ", secondName, " ", lastName, " ", secondLastName) AS fullName
    FROM User
    WHERE email=pEmail;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure findName
-- -----------------------------------------------------

DELIMITER $$
USE `userPostDB`$$
CREATE PROCEDURE `findName`(pChar VARCHAR(20))
    COMMENT 'Find a full name that contain specific chars'
BEGIN
	SELECT name, secondName, lastName, secondLastName
    FROM User
    WHERE name LIKE CONCAT('%',pChar,'%') OR 
		secondName LIKE CONCAT('%',pChar,'%') OR
		lastName LIKE CONCAT('%',pChar,'%') OR
        secondLastName LIKE CONCAT('%',pChar,'%');
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure existUser
-- -----------------------------------------------------

DELIMITER $$
USE `userPostDB`$$
CREATE PROCEDURE `existUser`(pEmail VARCHAR(254))
    COMMENT 'It validate If an user email already exist'
BEGIN
	SELECT COUNT(email)
    FROM User
    WHERE email=pEmail;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure allGender
-- -----------------------------------------------------

DELIMITER $$
USE `userPostDB`$$
CREATE PROCEDURE `allGender`(pGender INT)
    COMMENT 'Selec all users of same gender'
BEGIN
	SELECT name, secondName, lastName, secondLastName
    FROM User
    WHERE genderId=pGender;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure correctPassword
-- -----------------------------------------------------

DELIMITER $$
USE `userPostDB`$$
CREATE PROCEDURE `correctPassword`(pEmail VARCHAR(254), pPassword VARCHAR(65))
    COMMENT 'Validate if the password is correct'
BEGIN
    SELECT COUNT(email)
    FROM User
    WHERE email=pEmail AND password=PASSWORD(pPassword);
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure getSession
-- -----------------------------------------------------

DELIMITER $$
USE `userPostDB`$$
CREATE PROCEDURE `getSession`(pEmail VARCHAR(254))
    COMMENT 'get session of user'
BEGIN
	SELECT session
    FROM User
    WHERE email=pEmail;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure setSession
-- -----------------------------------------------------

DELIMITER $$
USE `userPostDB`$$
CREATE PROCEDURE `setSession`(pEmail VARCHAR(254), pSession VARCHAR(30))
    COMMENT 'Set the value of user session'
BEGIN
	UPDATE User
    SET session=pSession
    WHERE email=pEMail;
    COMMIT;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure setPassword
-- -----------------------------------------------------

DELIMITER $$
USE `userPostDB`$$
CREATE PROCEDURE `setPassword`(pEmail VARCHAR(254), pPassword VARCHAR(65))
    COMMENT 'Set password of user'
BEGIN
	UPDATE User
    SET password=pPassword
    WHERE email=pEmail;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure newPost
-- -----------------------------------------------------

DELIMITER $$
USE `userPostDB`$$
CREATE PROCEDURE `newPost`(pUser VARCHAR(254), pText VARCHAR(256), 
							pImage VARCHAR(64), pVideo VARCHAR(64))
    COMMENT 'New post of user'
BEGIN
	INSERT INTO Post (userId, text, image, video)
    VALUE(pUser, pText, pImage, pVideo);
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure delPost
-- -----------------------------------------------------

DELIMITER $$
USE `userPostDB`$$
CREATE PROCEDURE `delPost`(pPost INT, pUser VARCHAR(254))
    COMMENT 'Delete a post'
BEGIN
	DELETE FROM Post
    WHERE postId=pPost AND userId=pUser;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure newGender
-- -----------------------------------------------------

DELIMITER $$
USE `userPostDB`$$
CREATE PROCEDURE `newGender`(pGender VARCHAR(15))
    COMMENT 'Insert new gender'
BEGIN
	INSERT INTO Gender(gender)
    VALUE(pGender);
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure getCountries
-- -----------------------------------------------------

DELIMITER $$
USE `userPostDB`$$
CREATE PROCEDURE `getCountries`()
    COMMENT 'Get a list of all countries'
BEGIN
	SELECT countryId, Country
    FROM Country;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure getGenders
-- -----------------------------------------------------

DELIMITER $$
USE `userPostDB`$$
CREATE PROCEDURE `getGenders`()
    COMMENT 'get a list of all genders'
BEGIN
	SELECT genderId, gender
    FROM Gender;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure newCountry
-- -----------------------------------------------------

DELIMITER $$
USE `userPostDB`$$
CREATE PROCEDURE `newCountry`(pCountry VARCHAR(50))
    COMMENT 'Insert new country name'
BEGIN
	INSERT INTO Country (country)
    VALUE(pCountry);
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure getUserData
-- -----------------------------------------------------

DELIMITER $$
USE `userPostDB`$$
CREATE PROCEDURE `getUserData`(pUser VARCHAR(254))
    COMMENT 'Get all general data from user'
BEGIN
	SELECT name, secondName, lastName, secondLastName, genderId, countryId, description , birthdate, imageId
    FROM User
    WHERE email=pUser;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure getFollowerInfo
-- -----------------------------------------------------

DELIMITER $$
USE `userPostDB`$$
CREATE PROCEDURE `getFollowerInfo`(pEmail VARCHAR(254))
    COMMENT 'It returns user full name'
BEGIN
	SELECT CONCAT(name, " ", secondName, " ", lastName, " ", secondLastName) AS fullName, imageId, gender, count(Post.userId) AS posts
    FROM User, Gender, Post
    WHERE email=pEmail and Gender.genderId = User.genderId and Post.userId = pEmail;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure getNameAndImageId
-- -----------------------------------------------------

DELIMITER $$
USE `userPostDB`$$
CREATE PROCEDURE `getNameAndImageId`(pEmail VARCHAR(254))
    COMMENT 'It returns the name and the image ID of a user'
BEGIN
	SELECT CONCAT(name, " ", secondName, " ", lastName, " ", secondLastName) AS fullName, imageId
    FROM User
    WHERE email=pEmail;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure getUserPosts
-- -----------------------------------------------------

DELIMITER $$
USE `userPostDB`$$
CREATE PROCEDURE `getUserPosts`(pUsers VARCHAR(21845), pDays INT)
    COMMENT 'It returns the posts no older than pDays of a user'
BEGIN
	SET @query = CONCAT ('SELECT CONCAT(name, " ", secondName, " ", lastName, " ", secondLastName) AS fullName, postId, User.imageId, text, image, video, datetime
    FROM User, Post
    WHERE (User.email IN (', pUsers,')) AND (Post.userId = User.email) AND Post.datetime >= ( CURDATE() - INTERVAL ', pDays ,' DAY )
    ORDER BY Post.datetime DESC;');
    PREPARE stmt FROM @query;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure getMostRecentPostDatetime
-- -----------------------------------------------------

DELIMITER $$
USE `userPostDB`$$
CREATE PROCEDURE `getMostRecentPostDatetime`()
BEGIN
	SELECT dateTime
    FROM Post
    ORDER BY dateTime DESC
    LIMIT 1;    
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure searchUsers
-- -----------------------------------------------------

DELIMITER $$
USE `userPostDB`$$
CREATE PROCEDURE `searchUsers`(pActualUser VARCHAR(254), pSearchWord VARCHAR(50))
BEGIN
	SELECT CONCAT(name, " ", secondName, " ", lastName, " ", secondLastName) AS fullName, email,imageId, gender
    FROM User, Gender
    WHERE (CONCAT(name, " ", secondName, " ", lastName, " ", secondLastName) like CONCAT('%',pSearchWord, '%')) and Gender.genderId = User.genderId and User.email <> pActualUser;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure getUserImageId
-- -----------------------------------------------------

DELIMITER $$
USE `userPostDB`$$
CREATE PROCEDURE `getUserImageId`(pEmail VARCHAR(254))
    COMMENT 'It returns the name and the image ID of a user'
BEGIN
	SELECT imageId
    FROM User
    WHERE email=pEmail;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure getUserProfile
-- -----------------------------------------------------

DELIMITER $$
USE `userPostDB`$$
CREATE PROCEDURE `getUserProfile`(pEmail VARCHAR(254))
    COMMENT 'It returns user info for profile'
BEGIN
	SELECT CONCAT(name, " ", secondName, " ", lastName, " ", secondLastName) AS fullName, imageId, gender, country, description, birthdate, count(Post.userId) AS posts
    FROM User, Gender, Post, Country
    WHERE email=pEmail and Gender.genderId = User.genderId and Country.countryId = User.countryId and Post.userId = pEmail;
END$$

DELIMITER ;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
