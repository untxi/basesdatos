<?php
class UserService{

// Connection \\
/*
INPUT:  Connection parameters
OUTPUT: connection
*/
	function connectionUser($hostname, $user, $password, $dbname, $port){
		$connection = mysqli_connect('hostname', 'user', 'password', 'dbname', 'port');
		return $connection;
	}
/*
INPUT:  connection
OUTPUT: TRUE, if conecction is done
		Error Message, if connection failed
*/
	function checkConnection($connection){
		if ($connection->connect_error) {
			die("Connection failed: " . $connection->connect_error);
		}else{
			return TRUE;
		}
	}

/*
INPUT:  connection
OUTPUT: None
*/
	function desconect($connection){
		$connection->close();
	}

// Insert Data \\
/*
INPUT:  
OUTPUT: 
*/
	function newUser($connection, $pEmail, $pPassword, $pSession, $pName, $pSecondName, $pLastName, $pSecondLastName,
		$pGender, $pCountry, $pDescription, $pBirthdate, $pImageId){

		if (strlen($pEmail) > 254){echo 'Error in length of email';}
		if (strlen($pPassword) > 65){echo 'Error in length of password';}
		if (strlen($pSession) > 30){echo 'Error in length of session';}
		if (strlen($pName) > 20){echo 'Error in length of name';}
		if (strlen($pSecondName) > 20){echo 'Error in length of second name';}
		if (strlen($pLastName) > 20){echo 'Error in length of last name';}
		if (strlen($pSecondLastName) > 20){echo 'Error in length of second last name';}
		if (strlen($pDescription) > 350){echo 'Error in length of description';}

		$result = mysqli_query($connection, "CALL `registerUser` ('pEmail', 'pPassword', 'pSession', 'pName', 'pSecondName',
			'pLastName','pSecondLastName', 'pGender', 'pCountry', 'pDescription', 'pBirthdate', 'pImageId'");

		if ($connection->query($result) === TRUE) {
			echo 'Run successfully';
			return TRUE;
		}else{
			echo 'Error: ' . $result . '<br>' . $connection->error;
			return FALSE;
		}
	}


// Get Data \\
/*
INPUT:  
OUTPUT: 
*/
		function getUserData($connection, $pUser){
		$result = mysqli_query($connection, "CALL getUserData('pUser')" or die('Query fail: ' . mysqli_error()));
		
		if ($connection->query($result) === TRUE) {
			echo 'Run successfully';

			return $result;

		} else {
			echo 'Error: ' . $result . '<br>' . $connection->error;
		}
	}

/*
INPUT:  
OUTPUT: 
*/
	function userByGender($connection, $pGender){
		$result = mysqli_query($connection, "CALL allGender('pGender')" or die('Query fail: ' . mysqli_error()));

		if ($connection->query($result) === TRUE) {
			echo 'Run successfully';

			return $result;

		} else {
			echo 'Error: ' . $result . '<br>' . $connection->error;
		}
	}

/*
INPUT:  
OUTPUT: 
*/
	function userByName($connection, $pWord){
		$result = mysqli_query($connection, "CALL findName('pWord')" or die('Query fail: ' . mysqli_error()));

		if ($connection->query($result) === TRUE) {
			echo 'Run successfully';

			return $result;

		} else {
			echo 'Error: ' . $result . '<br>' . $connection->error;
		}

	}

/*
INPUT:  
OUTPUT: 
*/
	function getSession($connection, $pUser){
		$result = mysqli_query($connection, "CALL getSession('pUser')" or die('Query fail: ' . mysqli_error()));

		if ($connection->query($result) === TRUE) {
			echo 'Run successfully';

			return $result;

		} else {
			echo 'Error: ' . $result . '<br>' . $connection->error;
		}

	}

/*
INPUT:  
OUTPUT: 
*/
	function getGenders($connection){
		$result = mysqli_query($connection, "CALL getGenders()" or die('Query fail: ' . mysqli_error()));
		
		if ($connection->query($result) === TRUE) {
			echo 'Run successfully';

			return $result;

		} else {
			echo 'Error: ' . $result . '<br>' . $connection->error;
		}
	}

/*
INPUT:  
OUTPUT: 
*/
	function genderID($connection, $pGender){
		$result = mysqli_query($connection, "CALL getGenderID('pGender')" or die('Query fail: ' . mysqli_error()));

		if ($connection->query($result) === TRUE) {
			echo 'Run successfully';

			return $result;

		} else {
			echo 'Error: ' . $result . '<br>' . $connection->error;
		}

	}

/*
INPUT:  
OUTPUT: 
*/
	function getCountries($connection){
		$result = mysqli_query($connection, "CALL getCountries()" or die('Query fail: ' . mysqli_error()));
		
		if ($connection->query($result) === TRUE) {
			echo 'Run successfully';

			return $result;

		} else {
			echo 'Error: ' . $result . '<br>' . $connection->error;
		}
	}

/*
INPUT:  
OUTPUT: 
*/
	function allCountries($connection){
		$result = mysqli_query($connection, "CALL getCoutries()" or die('Query fail: ' . mysqli_error()));

		if ($connection->query($result) === TRUE) {
			echo 'Run successfully';

			return $result;

		} else {
			echo 'Error: ' . $result . '<br>' . $connection->error;
		}

	}

// Verify Data  \\
/*
INPUT:  
OUTPUT: 
*/

	function isUser($connection, $pEmail, $pPassword){
		// Revisamos la contraseña, si el resultado no es mayor que 0, nos morimos
		$checkPass = $connection->prepare("CALL correctPassword('" . $pEmail . "', '" . $pPassword . "')");
                $checkPass->execute();
               
                // AQUI ESTÁ EL ERROR
                if ($checkPass->num_rows > 0) {
                        // Generamos una sesion para el usuario
                        // Esta sesion le permite al usuario poder hacer cambios en las bases de datos
                        // Por ejemplo, subir un post, mandar un mensaje a otra persona, seguir a una persona, etc.
                        $session = bin2hex(openssl_random_pseudo_bytes(15));
                        
                        $checkPass->close();
                        
                        // Hay que guardarla en la base de datos                        
                        if ($connection->query("CALL setSession('$pEmail', '$session')")) {
                        
                            // Tenemos que traernos el nombre completo del usuario                            
                            if ($userData = $connection->query("CALL getUserData('$pEmail')")) {
                                // Y ponemos los datos relevantes del usuario en los cookies
                                // Esta función solo devuelve una fila (en teoria)
                                
                                 while($row = $userData->fetch_assoc()) {
                                    
                                    
                                    setcookie('id', $pEmail, 0);
                                    setcookie('name', $row["name"], 0);
                                    setcookie('secondName', $row["secondName"], 0);
                                    setcookie('lastName', $row["lastName"], 0);
                                    setcookie('secondLastName', $row["secondLastName"], 0);
                                    setcookie('session', $session, 0);
                                }
                                
                                echo "{'RETURN_CODE': 'OK'}";
                            
                            } else {
                                echo "{'RETURN_CODE': 'CANT_GET_DATA'}";
                            }

                        } else {
                            echo "{'RETURN_CODE': 'CANT_SET_SESSION'}";
                        }

		} else {
                    echo "{'RETURN_CODE': 'WRONG_PASS'}";
		}
	}

	
}

// Ejecuten esto desde la base de datos
// CALL registerUser('a', 'a', 'pSession', 'pName', 'pSecondName', 'pLastName', 'pSecondLastName', 1, 1, 'pDescription', STR_TO_DATE('01,5,2013','%d,%m,%Y'), 'pImageId');

$myConnection = mysqli_connect('localhost', 'root', 'root', 'userPostDB','3306');

$UserService = new UserService();
$UserService->isUser($myConnection, "a", "a");

?>