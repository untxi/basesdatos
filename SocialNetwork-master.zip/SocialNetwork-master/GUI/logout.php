<?php
    setcookie('id', '', 0, '/');
    setcookie('name', '', 0, '/');
    setcookie('secondName', '', 0, '/');
    setcookie('lastName', '', 0, '/');
    setcookie('secondLastName', '', 0, '/');
    setcookie('session', '', 0, '/');

    echo '<script>alert("Thanks for using this amazing social network!"); window.location.href = "login.html";</script>';
?>