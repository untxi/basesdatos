<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>KIT | News Feed</title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-progressbar -->
    <link href="../vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
    <!-- JQVMap -->
    <link href="../vendors/jqvmap/dist/jqvmap.min.css" rel="stylesheet"/>

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
    <link href="css/loading.css" rel="stylesheet">
  </head>

  
        <?php include('headerAndSidebar.php') ?>
            

        <!-- page content -->
        <div class="right_col" role="main">
          
          <div class="row">
            <div class="page-title">
              <div class="title_left">
                <h3>News Feed</h3>
              </div>
            </div>
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>New Post <small>Share your feelings!</small></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <form class="form-horizontal form-label-left" novalidate id="newPostForm" method="POST" enctype="multipart/form-data" autocomplete="off">
                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="textarea">Post <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <textarea id="postText" required="required" name="postText" class="form-control col-md-7 col-xs-12"></textarea>
                        </div>
                      </div>
                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Subir Imagen </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input class="btn btn-primary" type="file" title="Imagen" name="picture" id="picture" accept="image/*">
                        </div>
                      </div>
                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Subir Video </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input class="btn btn-primary" type="file" title="Video" name="video" id="video" accept="video/mp4">
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="col-md-6 col-md-offset-5">
                          <button id="send" type="submit" class="btn btn-success">Post!</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>

          </br>

          <div class="row">
            <div class="page-title">
              <div class="title_left">
                <h3>Posts</h3>
              </div>
              <div class="clearfix"></div>
              <div id="postsDiv">
              </div>
            </div>

            <!-- Código para Post solo Texto -->
            <!-- <div class="row">
              <div class="col-md-8 col-sm-12 col-xs-12 col-md-offset-2">
                <div class="x_panel">
                  <div>                      
                      <h2><img src="images/img.jpg" alt="..." class="img-circle profile_img" style="width:70px;height:70px;">Kevin Lobo Chinchilla</h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_title">
                    <h2><i class="fa fa-file-text-o"></i>  Post</small></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <p>Raw denim you probably haven't heard of them jean shorts Austin. Nesciunt tofu stumptown aliqua, retro synth master cleanse. Mustache cliche tempor, williamsburg carles vegan helvetica. Reprehenderit butcher retro keffiyeh dreamcatcher synth. Cosby sweater eu banh mi, qui irure terr.</p>
                  </div> -->
                  <!-- Para darle like -->
                  <!-- <a class="btn btn-app">
                      <span class="badge bg-blue">102</span>
                      <i class="fa fa-heart-o"></i> Like
                    </a>
                </div>
              </div>
            </div> -->
            <!-- Código para Post solo Texto -->

            <!-- Código para Post con Imagen -->
           <!--  <div class="row">
              <div class="col-md-8 col-sm-12 col-xs-12 col-md-offset-2">
                <div class="x_panel">
                  <div>                      
                      <h2><img src="images/img.jpg" alt="..." class="img-circle profile_img" style="width:70px;height:70px;">Kevin Lobo Chinchilla</h2>
                    <div class="clearfix"></div>
                  <div class="x_title">
                    <h2><i class="fa fa-file-text-o"></i>  Post</small></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <p>Raw denim you probably haven't heard of them jean shorts Austin. Nesciunt tofu stumptown aliqua, retro synth master cleanse. Mustache cliche tempor, williamsburg carles vegan helvetica. Reprehenderit butcher retro keffiyeh dreamcatcher synth. Cosby sweater eu banh mi, qui irure terr.</p>
                  </div>
                  <div class="x_title">
                    <h2><i class="fa fa-file-image-o"></i>  Imagen</small></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content ">
                    <img src="images/prod-1.jpg" class="img-responsive" style="width: 50%; margin: 0 auto;">
                  </div> -->
                  <!-- Cuando se le dio like -->
                  <!-- <a class="btn btn-app">
                      <span class="badge bg-blue">102</span>
                      <i class="fa fa-heart"></i> Liked
                    </a>
                </div>
              </div>
            </div>
            </div> -->
            <!-- Código para Post con Imagen -->

          <!-- Código para Post con Video -->
            <!-- <div class="row">
              <div class="col-md-8 col-sm-12 col-xs-12 col-md-offset-2">
                <div class="x_panel">
                  <div>                      
                      <h2><img src="images/img.jpg" alt="..." class="img-circle profile_img" style="width:70px;height:70px;">Kevin Lobo Chinchilla</h2>
                    <div class="clearfix"></div>
                  <div class="x_title">
                    <h2><i class="fa fa-file-text-o"></i>  Post</small></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <p>Raw denim you probably haven't heard of them jean shorts Austin. Nesciunt tofu stumptown aliqua, retro synth master cleanse. Mustache cliche tempor, williamsburg carles vegan helvetica. Reprehenderit butcher retro keffiyeh dreamcatcher synth. Cosby sweater eu banh mi, qui irure terr.</p>
                  </div>
                  <div class="x_title">
                    <h2><i class="fa fa-file-video-o"></i>  Video</small></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <div class="embed-responsive embed-responsive-16by9">
                    <video class="embed-responsive-item" width="320" height="240" controls>
                      <source src="videos/movie.mp4" type="video/mp4">
                      Your browser does not support the video tag.
                    </video>
                  </div>
                  </div> -->
                  <!-- Cuando se le dio like -->
                  <!-- <a class="btn btn-app">
                      <span class="badge bg-blue">102</span>
                      <i class="fa fa-heart"></i> Liked
                    </a>
                </div>
              </div>
            </div>
            </div> -->
            <!-- Código para Post con Video -->

          <!-- Código para Post con Imagen y Video -->
            <!-- <div class="row">
              <div class="col-md-8 col-sm-12 col-xs-12 col-md-offset-2">
                <div class="x_panel">
                  <div>                      
                      <h2><img src="images/img.jpg" alt="..." class="img-circle profile_img" style="width:70px;height:70px;">Kevin Lobo Chinchilla</h2>
                    <div class="clearfix"></div>
                  <div class="x_title">
                    <h2><i class="fa fa-file-text-o"></i>  Post</small></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <p>Raw denim you probably haven't heard of them jean shorts Austin. Nesciunt tofu stumptown aliqua, retro synth master cleanse. Mustache cliche tempor, williamsburg carles vegan helvetica. Reprehenderit butcher retro keffiyeh dreamcatcher synth. Cosby sweater eu banh mi, qui irure terr.</p>
                  </div>
                  <div class="x_title">
                    <h2><i class="fa fa-file-image-o"></i>  Imagen</small></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <img src="images/prod-1.jpg" class="img-responsive" style="width: 50%; margin: 0 auto;">
                  </div>
                  <div class="x_title">
                    <h2><i class="fa fa-file-video-o"></i>  Video</small></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                  <div class="embed-responsive embed-responsive-16by9">
                    <video class="embed-responsive-item" width="320" height="240" controls>
                      <source src="videos/movie.mp4" type="video/mp4">
                      Your browser does not support the video tag.
                    </video>
                  </div> 
                  </div> -->
                  <!-- Cuando se le dio like -->
                  <!-- <a class="btn btn-app">
                      <span class="badge bg-blue">102</span>
                      <i class="fa fa-heart"></i> Liked
                    </a>
                </div>
              </div>
            </div>
            </div> -->
            <!-- Código para Post con Imagen y Video -->
          <br />
        </div>

        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
            Gentelella - Bootstrap Admin Template by <a href="https://colorlib.com">Colorlib</a>
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>


    <!-- jQuery -->
    <script src="js/posts.js"></script>

  </body>
</html>
