 $().ready(function() {

  $('body').on('click', '.likeButton', function(event) {
    var postId = $(this).attr('id');
    var totalPostLikes = "";
    var returnCode = "";
    $.ajax({
        type: "POST",
        url: "../API/postsAPI.php",
        dataType: 'json',
        async: false,
        data: {
            action: 4,
            postId: postId 
        },
        success: function(data) {
            totalPostLikes = data["postLikes"];
            returnCode = data["RETURN_CODE"];
            
        },
        error : function(data) {
            alert("Ha ocurrido un error." + JSON.stringify(data));
        }
    });
    if (returnCode == "LIKED"){
      $(this).html(`<span class="badge bg-blue">`+totalPostLikes+`</span>`+'<i class="fa fa-heart"></i> Liked');
    } else if (returnCode == "DISLIKED"){
      $(this).html(`<span class="badge bg-blue">`+totalPostLikes+`</span>`+'<i class="fa fa-heart-o"></i> Like');
    }
  });


  var firstLatestPost = Date.parse('Thu, 01 Jan 1970 00:00:00');
  loadPosts();

  setInterval(function(){ 
    $.ajax({
      type: "POST",
      url: "../API/postsAPI.php",
      dataType: "json",
      async: false,
      data: {
          action: 3,
      },
      success: function(data) {
          var latestPost = data["latestPost"];
          firstLatestPostHere = Date.parse(firstLatestPost);
          latestPost = Date.parse(latestPost);
          if (firstLatestPostHere < latestPost){
            loadPosts();
          }
      },
      error : function(data) {
          alert("Ha ocurrido un error." + JSON.stringify(data));
      }
    }); 
  }, 3000);

  function loadPosts(){
    $("#postsDiv").html('');
    $("#postsDiv").addClass("modal"); console.log("loadingPosts");
    $.ajax({
      type: "POST",
      url: "../API/postsAPI.php",
      dataType: "json",
      async: false,
      data: {
          action: 2,
      },
      success: function(data) {
        if (data["RETURN_CODE"] == "NO_FOLLOWING"){
          return false;
        }
        firstLatestPost = data["latestPost"];            
            $.each(data["posts"], function(i, post){
                var name = post["userName"];
                var userImage = post["userImage"];
                var likedOrNot = '<i class="fa fa-heart-o"></i> Like'
                if (post["actualUserLikes"]){
                  likedOrNot = '<i class="fa fa-heart"></i> Liked'
                }
                switch(post["type"]){
                    case "ONLY_TEXT":
                        insertTextPost(name, userImage, post, likedOrNot);
                        break;
                    case "TEXT_IMAGE":
                        insertTextImagePost(name, userImage, post, likedOrNot);
                        break;
                    case "TEXT_VIDEO":
                        insertTextVideoPost(name, userImage, post, likedOrNot);
                        break;
                    case "TEXT_IMAGE_VIDEO":
                        insertTextImageVideoPost(name, userImage, post, likedOrNot);
                        break;
                    case "ONLY_IMAGE":
                        insertImagePost(name, userImage, post, likedOrNot);
                        break;
                    case "IMAGE_VIDEO":
                        insertImageVideoPost(name, userImage, post, likedOrNot);
                        break;
                    case "ONLY_VIDEO":
                        insertVideoPost(name, userImage, post, likedOrNot);
                        break;
                }
            });
        console.log(Date.parse(firstLatestPost));        
      },
      error : function(data) {
          alert("Ha ocurrido un error." + JSON.stringify(data));
      }
  });
    $("#postsDiv").removeClass("modal");
  }

    function insertTextPost(name, userImage, post, likedOrNot){
        var html = `<div class="row">
              <div class="col-md-8 col-sm-12 col-xs-12 col-md-offset-2">
                <div class="x_panel">
                  <div>                      
                      <h2><img src="`+userImage+`" alt="..." class="img-circle profile_img" style="width:70px;height:70px;">
                      `+name+`</h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_title">
                    <h2><i class="fa fa-clock-o"></i>  `+post["datetime"]+`</small></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_title">
                    <h2><i class="fa fa-file-text-o"></i>  Post</small></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <pre>`+post["text"]+`</pre>
                  </div>
                  <!-- Para darle like -->
                  <a id="`+post["postId"]+`" class="btn btn-app likeButton">
                      <span class="badge bg-blue">`+post["likes"]+`</span>
                      `+likedOrNot+`
                    </a>
                </div>
              </div>
            </div>`;
        $("#postsDiv").append(html);
    }

    function insertTextImagePost(name, userImage, post, likedOrNot){
        var html = `<div class="row">
              <div class="col-md-8 col-sm-12 col-xs-12 col-md-offset-2">
                <div class="x_panel">
                  <div>                      
                      <h2><img src="`+userImage+`" alt="..." class="img-circle profile_img" style="width:70px;height:70px;">
                      `+name+`</h2>
                    <div class="clearfix"></div>
                    <div class="x_title">
                    <h2><i class="fa fa-clock-o"></i>  `+post["datetime"]+`</small></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_title">
                    <h2><i class="fa fa-file-text-o"></i>  Post</small></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <pre>`+post["text"]+`</pre>
                  </div>
                  <div class="x_title">
                    <h2><i class="fa fa-file-image-o"></i>  Imagen</small></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content ">
                    <img src=`+post["image"]+` class="img-responsive" style="width: 50%; margin: 0 auto;">
                  </div>
                  <!-- Cuando se le dio like -->
                  <a id="`+post["postId"]+`" class="btn btn-app likeButton">
                      <span class="badge bg-blue">`+post["likes"]+`</span>
                      `+likedOrNot+`
                    </a>
                </div>
              </div>
            </div>
            </div>`;
        $("#postsDiv").append(html);
    }

    function insertTextVideoPost(name, userImage, post, likedOrNot){
        var html = `<div class="row">
              <div class="col-md-8 col-sm-12 col-xs-12 col-md-offset-2">
                <div class="x_panel">
                  <div>                      
                      <h2><img src="`+userImage+`" alt="..." class="img-circle profile_img" style="width:70px;height:70px;">
                      `+name+`</h2>
                    <div class="clearfix"></div>
                    <div class="x_title">
                    <h2><i class="fa fa-clock-o"></i>  `+post["datetime"]+`</small></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_title">
                    <h2><i class="fa fa-file-text-o"></i>  Post</small></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <pre>`+post["text"]+`</pre>
                  </div>
                  <div class="x_title">
                    <h2><i class="fa fa-file-video-o"></i>  Video</small></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <div class="embed-responsive embed-responsive-16by9">
                    <video class="embed-responsive-item" width="320" height="240" controls>
                      <source type="video/mp4" src=`+post["video"]+`>
                      Your browser does not support the video tag.
                    </video>
                  </div>
                  </div>
                  <!-- Cuando se le dio like -->
                  <a id="`+post["postId"]+`" class="btn btn-app likeButton">
                      <span class="badge bg-blue">`+post["likes"]+`</span>
                      `+likedOrNot+`
                    </a>
                </div>
              </div>
            </div>
            </div>`;
        $("#postsDiv").append(html);
    }

    function insertTextImageVideoPost(name, userImage, post, likedOrNot){
        var html = `<div class="row">
              <div class="col-md-8 col-sm-12 col-xs-12 col-md-offset-2">
                <div class="x_panel">
                  <div>                      
                      <h2><img src="`+userImage+`" alt="..." class="img-circle profile_img" style="width:70px;height:70px;">
                      `+name+`</h2>
                    <div class="clearfix"></div>
                    <div class="x_title">
                    <h2><i class="fa fa-clock-o"></i>  `+post["datetime"]+`</small></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_title">
                    <h2><i class="fa fa-file-text-o"></i>  Post</small></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <pre>`+post["text"]+`</pre>
                  </div>
                  <div class="x_title">
                    <h2><i class="fa fa-file-image-o"></i>  Imagen</small></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <img src="`+post["image"]+`" class="img-responsive" style="width: 50%; margin: 0 auto;">
                  </div>
                  <div class="x_title">
                    <h2><i class="fa fa-file-video-o"></i>  Video</small></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                  <div class="embed-responsive embed-responsive-16by9">
                    <video class="embed-responsive-item" width="320" height="240" controls>
                      <source type="video/mp4" src=`+post["video"]+`>
                      Your browser does not support the video tag.
                    </video>
                  </div> 
                  </div>
                  <!-- Cuando se le dio like -->
                  <a id="`+post["postId"]+`" class="btn btn-app likeButton">
                      <span class="badge bg-blue">`+post["likes"]+`</span>
                      `+likedOrNot+`
                    </a>
                </div>
              </div>
            </div>
            </div>`;
        $("#postsDiv").append(html);
    }

    function insertImagePost(name, userImage, post, likedOrNot){
        var html = `<div class="row">
              <div class="col-md-8 col-sm-12 col-xs-12 col-md-offset-2">
                <div class="x_panel">
                  <div>                      
                      <h2><img src="`+userImage+`" alt="..." class="img-circle profile_img" style="width:70px;height:70px;">
                      `+name+`</h2>
                    <div class="clearfix"></div>
                    <div class="x_title">
                    <h2><i class="fa fa-clock-o"></i>  `+post["datetime"]+`</small></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_title">
                    <h2><i class="fa fa-file-image-o"></i>  Image</small></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content ">
                    <img src=`+post["image"]+`  class="img-responsive" style="width: 50%; margin: 0 auto;">
                  </div>
                  <!-- Cuando se le dio like -->
                  <a id="`+post["postId"]+`" class="btn btn-app likeButton">
                      <span class="badge bg-blue">`+post["likes"]+`</span>
                      `+likedOrNot+`
                    </a>
                </div>
              </div>
            </div>
            </div>`;
        $("#postsDiv").append(html);
    }

    function insertImageVideoPost(name, userImage, post, likedOrNot){
        var html = `<div class="row">
              <div class="col-md-8 col-sm-12 col-xs-12 col-md-offset-2">
                <div class="x_panel">
                  <div>                      
                      <h2><img src="`+userImage+`" alt="..." class="img-circle profile_img" style="width:70px;height:70px;">
                      `+name+`</h2>
                    <div class="clearfix"></div>
                    <div class="x_title">
                    <h2><i class="fa fa-clock-o"></i>  `+post["datetime"]+`</small></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_title">
                    <h2><i class="fa fa-file-image-o"></i>  Image</small></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <img src=`+post["image"]+` class="img-responsive" style="width: 50%; margin: 0 auto;">
                  </div>
                  <div class="x_title">
                    <h2><i class="fa fa-file-video-o"></i>  Video</small></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                  <div class="embed-responsive embed-responsive-16by9">
                    <video class="embed-responsive-item" width="320" height="240" controls>
                      <source type="video/mp4" src=`+post["video"]+`>
                      Your browser does not support the video tag.
                    </video>
                  </div> 
                  </div>
                  <!-- Cuando se le dio like -->
                  <a id="`+post["postId"]+`" class="btn btn-app likeButton">
                      <span class="badge bg-blue">`+post["likes"]+`</span>
                      `+likedOrNot+`
                    </a>
                </div>
              </div>
            </div>
            </div>`;
        $("#postsDiv").append(html);
    }

    function insertVideoPost(name, userImage, post, likedOrNot){
        var html = `<div class="row">
              <div class="col-md-8 col-sm-12 col-xs-12 col-md-offset-2">
                <div class="x_panel">
                  <div>                      
                      <h2><img src="`+userImage+`" alt="..." class="img-circle profile_img" style="width:70px;height:70px;">
                      `+name+`</h2>
                    <div class="clearfix"></div>
                    <div class="x_title">
                    <h2><i class="fa fa-clock-o"></i>  `+post["datetime"]+`</small></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_title">
                    <h2><i class="fa fa-file-video-o"></i>  Video</small></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <div class="embed-responsive embed-responsive-16by9">
                    <video class="embed-responsive-item" width="320" height="240" controls>
                      <source type="video/mp4" src=`+post["video"]+`>
                      Your browser does not support the video tag.
                    </video>
                  </div>
                  </div>
                  <!-- Cuando se le dio like -->
                  <a id="`+post["postId"]+`" class="btn btn-app likeButton">
                      <span class="badge bg-blue">`+post["likes"]+`</span>
                      `+likedOrNot+`
                    </a>
                </div>
              </div>
            </div>
            </div>`;
        $("#postsDiv").append(html);
    }


    $("#newPostForm").on('submit', function(){
        var postText = $("#postText").val();
        var picture = $("#picture").val();
        var video = $("#video").val();
        if (postText == "" && picture == "" && video == ""){
            return false;
        }
        console.log(postText, picture, video);
        var formdata = new FormData($("#newPostForm")[0]);
        formdata.append("action", 1);
        $.ajax({
            type: "POST",
            url: "../API/postsAPI.php",
            dataType: "json",
            cache: false,
            contentType: false,
            processData: false,
            data: formdata,
            success: function(data) {
                if (data["RETURN_CODE"] == 'NOT_OK'){
                    alert("Sorry, your post could not be published.");
                    return false; 
                }              
                if (data["RETURN_CODE"] == "INVALID_IMAGE"){
                  alert("Invalid image format");
                  return false;
                }
                if (data["RETURN_CODE"] == "INVALID_VIDEO"){
                  alert("Invalid video encode or format");
                  return false;
                }
                alert("Post Published!");
                $("#newPostForm")[0].reset();
            },
            error : function(data) {
                alert("Ha ocurrido un error." + JSON.stringify(data));
            }
        });
        return false;
    });

        
});