$().ready(function() {

    var url = window.location.href;
    var urlAux = url.split('=');
    var userId = urlAux[1]
    console.log(userId);
    $.ajax({
        type: "POST",
        url: "../API/profileAPI.php",
        dataType: 'json',
        data: {
            action: 1,
            id: userId
        },
        success: function(data) {
            var fullName = data["fullName"];
            var userImage = data["userImage"];
            var gender = data["gender"];
            var country = data["country"];
            var description = data["description"];
            var birthdate = data["birthdate"];
            var postsCount = data["postsCount"];
            $("#userName").html(fullName);
            $("#userImage").attr("src", userImage);
            if (gender == "Male"){
              $("#gender").html('<i id="genderIcon" class="fa fa-male user-profile-icon"></i> '+gender)
            } else {
              $("#gender").html('<i id="genderIcon" class="fa fa-female user-profile-icon"></i> '+gender)
            }
            $("#userCountry").html('<i class="fa fa-map-marker user-profile-icon"></i> '+country);
            $("#birthdate").html('<i class="fa fa-birthday-cake user-profile-icon"></i> '+birthdate);
            $("#posts").html('<i class="fa fa-send user-profile-icon"></i> Total Posts = '+postsCount);
            $("#description").html(description);
        },
        error : function(data) {
            alert("Ha ocurrido un error." + JSON.stringify(data));
        }
    });
  });
