$().ready(function() {

  $('body').on('click', '.followButton', function(event) {
    var userId = $(this).attr('id');
    $.ajax({
        type: "POST",
        url: "../API/followsAPI.php",
        dataType: 'json',
        data: {
            action: 1,
            userToFollowId: userId 
        },
        success: function(data) {
            if (data["RETURN_CODE"] != "FOLLOW" && data["RETURN_CODE"] != "UNFOLLOW"){
              alert("Something bad happened :(");
            }
        },
        error : function(data) {
            alert("Ha ocurrido un error." + JSON.stringify(data));
        }
    });
    if ($(this).html() == "Unfollow!"){
        $(this).html("Follow!");
      } else {
        $(this).html("Unfollow!");
      }
  });

  $("#searchUserButton").on("click", function(){
    var searchWord = $("#searchWord").val();
    $.ajax({
        type: "POST",
        url: "../API/followsAPI.php",
        dataType: 'json',
        data: {
            action: 4,
            searchWord: searchWord 
        },
        success: function(data) {
            if (data["totalUsers"] == 0){
                alert ("No one found!");
                return false; 
            }
            var html = "";
            var totalFound = data["totalUsers"];
            var totalMales = data["totalMales"];
            var totalFemales = data["totalFemales"];
            $.each(data["users"], function(i, item){
              var buttonLabel = "Follow!";
                if (item["FOLLOWING"] == "TRUE"){
                  buttonLabel = "Unfollow!";
                }
                html += `<div class="col-md-3 col-xs-12 widget widget_tally_box">
                        <div class="x_panel fixed_height_300">
                          <div class="x_content">

                            <div class="flex">
                              <ul class="list-inline widget_profile_box">
                                <li>
                                  <a>
                                    <i class="fa fa-quote-left"></i>
                                  </a>
                                </li>
                                <li>
                                  <img src="`+item['picture']+`" alt="..." class="img-circle profile_img">
                                </li>
                                <li>
                                  <a>
                                    <i class="fa fa-quote-right"></i>
                                  </a>
                                </li>
                              </ul>
                            </div>
                            <h3 class="name"><a href="profile.php?userid=`+item["id"]+`">`+item["name"]+`</a></h3>
                            <div class="flex">
                              <button id="`+item["id"]+`" class="followButton">`+buttonLabel+`</button>
                            </div>
                          </div>
                        </div>
                      </div>`;
                      
            });
            $("#usersDiv").html(html);
            $("#totalFoundDiv").html(totalFound);
            $("#totalMalesDiv").html(totalMales);
            $("#totalFemalesDiv").html(totalFemales);
        },
        error : function(data) {
            alert("Ha ocurrido un error." + JSON.stringify(data));
        }
    });
  });
    
});
