


 $().ready(function() {

    localStorage.removeItem("userImg");

    $('#birthday').daterangepicker({
        singleDatePicker: true,
        showDropdowns:true,
        calender_style: "picker_4"
    });

    $.ajax({
            type: "POST",
            url: "../API/loginRegisterAPI.php",
            dataType: "json",
            data: {
                action: 2,
            },
            success: function(data) {
                addGenders(data);
            },
            error : function(data) {
                alert("Ha ocurrido un error." + JSON.stringify(data));
            }
        });

    $.ajax({
            type: "POST",
            url: "../API/loginRegisterAPI.php",
            dataType: "json",
            data: {
                action: 3,
            },
            success: function(data) {
                addCountries(data);
            },
            error : function(data) {
                alert("Ha ocurrido un error." + JSON.stringify(data));
            }
        });

    function addCountries(data){
        var html = '<option value="none">Select Country</option>';
        $.each(data["countries"], function(i, item){
                html += '<option value="'+item["id"]+'">'+item["country"]+'</option>'                      
        });
        $("#country").html(html);

    };

    function addGenders(data){
        var html = '<option value="none">Select Gender</option>';
        $.each(data["genders"], function(i, item){
                html += '<option value="'+item["id"]+'">'+item["gender"]+'</option>'                      
        });
        $("#gender").html(html);
    };


    $("#loginForm").on('submit', function(){
        var email = $("#email").val();
        var pass = $("#pass").val();
        console.log(email, pass);
        $.ajax({
            type: "POST",
            url: "../API/loginRegisterAPI.php",
            dataType: "json",
            data: {
                action: 1,
                email: email,
                password: pass
            },
            success: function(data) {
                if (data["RETURN_CODE"] == 'WRONG_PASS'){
                    alert("Nombre de usuario o contraseña incorrectos!");
                    return false;
                } else {
                    window.location.replace("index.php");
                }
            },
            error : function(data) {
                alert("Ha ocurrido un error." + JSON.stringify(data));
            }
        });
        return false;
    });

    $("#registerForm").on('submit', function(){
        var country = $("#country").val();
        var gender = $("#gender").val();
        var pass1 = $("#pass1").val();
        var pass2 = $("#pass2").val();
        if (country == "none"){
            alert("Please select a country");
            return false;
        }
        if (gender == "none"){
            alert("Please select a gender");
            return false;
        }
        if (pass1 != pass2){
            alert("Passwords do not match");
            return false;
        }

        var formdata = new FormData($("#registerForm")[0]);
        formdata.append("action", 4);
        $.ajax({
            type: "POST",
            url: "../API/loginRegisterAPI.php",
            dataType: "json",
            cache: false,
            contentType: false,
            processData: false,
            data: formdata,
            success: function(data) {
                if (data["RETURN_CODE"] == 'EMAIL_TAKEN'){
                    alert("An account with this email already exists.");
                    return false;
                } else {
                    alert("You have been registered");
                    window.location.replace("#signin");
                }
            },
            error : function(data) {
                alert("Ha ocurrido un error." + JSON.stringify(data));
            }
        });
        $(this)[0].reset()
        return false;
    });

        
});