// Autor: Víctor Chaves

$().ready(function() {

    var activeConversation = null;
    var currentConversations = 0;
    
    
    $("#sendMessageDiv").hide();
    
    function getCookie(name) {
        var regexp = new RegExp("(?:^" + name + "|;\s*"+ name + ")=(.*?)(?:;|$)", "g");
        var result = regexp.exec(document.cookie);
        return (result === null) ? null : result[1];
    }
   
    // --------------------------------------------------- //
    // Inicializamos la lista de conversaciones del usuario
    // --------------------------------------------------- //
    
    function getConversations() {
        $.ajax({
            type: "POST",
            url: "../API/chatAPI.php",
            dataType: 'json',
            data: {
                action: "getConversations"
            },
            success: function(data) {
                if (data.length == 0){
                    alert ("You don't have any conversations, why not start one?");
                    return false; 
                }
                
                currentConversations = 0;
                $("#conversationList").html("");
                $.each(data, function(i, item){
                    currentConversations += 1;
                    $('<a href="#" id="' + item["convID"] + '"><div class="mail_list"><div class="right"><h3>' + item["userName"] + '</h3></div></div></a>').addClass('convLink').appendTo("#conversationList");
                });
            },
            error : function(data) {
                alert("Ha ocurrido un error." + JSON.stringify(data));
            }
        });
    }
    
    getConversations();
        
        
    // --------------------------------------------------- //
    // Cargamos una conversación
    // --------------------------------------------------- //
    
    $("body").on('click', '.convLink', function() {
        
        // Con esto, obtengo el ID de la conversación actualmente activa
        if (activeConversation == jQuery(this).attr("id")) {
            return false;
        }
        
        activeConversation = jQuery(this).attr("id");
        
        $.ajax({
            type: "POST",
            url: "../API/chatAPI.php",
            dataType: 'json',
            data: {
                action: "getMessages",
                convID: activeConversation
            },
            success: function(data) {
                if (data.length == 0){
                    $("#messagesDiv").html("");
                    alert ("You don't have any messages on this conversation, why not send one?");
                    return false; 
                }
                
                var html = "";
                
                $.each(data, function(i, item){
                    html += `<div class="msg-wrap">
                                <div>
                                    <div class="media-body">
                                        <h5 class="media-heading">` + item["author"] + `</h5>
                                        <p class="col-lg-10">` + item["message"] + `</p>
                                    </div>
                                </div>

                            </div>`;
                        
                });
                
                $("#messagesDiv").html(html);
            },
            error : function(data) {
                alert("Ha ocurrido un error." + JSON.stringify(data));
            }
        });
        
        $("#sendMessageDiv").show();
    });
    
    
    // --------------------------------------------------- //
    // Enviamos un nuevo mensaje desde el chat
    // --------------------------------------------------- //
    $("#sendMessageButton").on('click', function() {
        var message = $("#messageBox").val();
        
        if (message == "") return;
        if (activeConversation == null) return;
            
        $.ajax({
            type: "POST",
            url: "../API/chatAPI.php",
            dataType: 'json',
            data: {
                action: "sendMessage",
                convID: activeConversation,
                msg: message
            },
            
            success: function(data) {
                var html = `<div class="msg-wrap">
                                <div>
                                    <div class="media-body">
                                        <h5 class="media-heading">` + data["author"] + `</h5>
                                        <p class="col-lg-10">` + data["message"] + `</p>
                                    </div>
                                </div>

                            </div>`;
                
                $("#messagesDiv").append(html);
            },
            error : function(data) {
                alert("Ha ocurrido un error." + JSON.stringify(data));
            }
        });
        
        $("#messageBox").val("");
                            
    });
    
    
    // --------------------------------------------------- //
    // Cargamos las personas a las que el usuario sigue
    // --------------------------------------------------- //
    $("#compose").click(function () {
        $("#followingList").html("");
        
        $.ajax({
            type: "POST",
            url: "../API/chatAPI.php",
            dataType: 'json',
            data: {
                action: "getUserFollowing"
            },
            
            success: function(data) {
                $.each(data, function(i, item){
                    $("#followingList").append(`<option value="`+ item["userID"] + `">` + item["userName"] + ` (` + item["userID"] + `)</option>`);
                });
            },
            error : function(data) {
                alert("Ha ocurrido un error." + JSON.stringify(data));
            }
        });    
    });
    
    
    // --------------------------------------------------- //
    // Cuando enviamos un nuevo mensaje desde la ventana de compose
    // --------------------------------------------------- //
    
    $("#sendNewMessage").click(function () {
        $.ajax({
            type: "POST",
            url: "../API/chatAPI.php",
            dataType: 'json',
            data: {
                action: "sendMessageTo",
                receiver: $("#followingList").val(),
                msg: $("#newMessageText").val()
            },
            
            success: function(data) {
                
                // Revisar si la conversacion actual es la que me devuelve el servidor
                if(data["convID"] == activeConversation) {
                    var html = `<div class="msg-wrap">
                                <div>
                                    <div class="media-body">
                                        <h5 class="media-heading">` + data["author"] + `</h5>
                                        <p class="col-lg-10">` + data["message"] + `</p>
                                    </div>
                                </div>

                            </div>`;
                
                    $("#messagesDiv").append(html);
                
                    
                // Revisar si la conversacion es nueva
                } else if (data["newConv"] == true) {
                    $('<a href="#" id="' + data["convID"] + '"><div class="mail_list"><div class="right"><h3>' + data["receiverName"] + '</h3></div></div></a>').addClass('convLink').appendTo("#conversationList");
                }
                
                $("#newMessageText").val("");
            },
            error : function(data) {
                alert("Ha ocurrido un error." + JSON.stringify(data));
            }
        });  
        
        
    });
    
    
    // --------------------------------------------------- //
    // Cada 3 segundos cargamos las conversaciones 
    // --------------------------------------------------- //
    setInterval(function(){ 
        $.ajax({
            type: "POST",
            url: "../API/chatAPI.php",
            dataType: "json",
            async: false,
            data: {
                action: "getConvNumber"
            },
            success: function(data) {
                if (data["totalConv"] != currentConversations) {
                    getConversations();
                } else {
                    console.log("No new conversations");
                }
            },
            error : function(data) {
                alert("Ha ocurrido un error." + JSON.stringify(data));
            }
        }); 
    }, 5000);

    
    // ---------------------------------------------------------------------------- //
    // Cada 3 segundos revisamos si hay mensajes nuevos en la conversacion actual
    // ---------------------------------------------------------------------------- //
    setInterval(function(){
        // Solo llamamos si hay conversacion activa
        if (activeConversation != null) {
            $.ajax({
                type: "POST",
                url: "../API/chatAPI.php",
                dataType: "json",
                async: false,
                data: {
                    action: "getUnseenMessagesNumber",
                    convID: activeConversation
                },
                success: function(data) {
                    getNewMessages(data["otherUserID"]);
                },
                error : function(data) {
                    alert("Ha ocurrido un error." + JSON.stringify(data));
                }
            });
        }
    }, 3000);
    
    
    function getNewMessages(otherUser) {
        $.ajax({
            type: "POST",
            url: "../API/chatAPI.php",
            dataType: 'json',
            data: {
                action: "getUnseenMessages",
                convID: activeConversation,
                otherUserID: otherUser
            },
            success: function(data) {
                var html = "";
                
                $.each(data, function(i, item){
                    html += `<div class="msg-wrap">
                                <div>
                                    <div class="media-body">
                                        <h5 class="media-heading">` + item["author"] + `</h5>
                                        <p class="col-lg-10">` + item["message"] + `</p>
                                    </div>
                                </div>

                            </div>`;
                        
                });
                
                $("#messagesDiv").append(html);
            },
            error : function(data) {
                alert("Ha ocurrido un error." + JSON.stringify(data));
            }
        });
    }
});
