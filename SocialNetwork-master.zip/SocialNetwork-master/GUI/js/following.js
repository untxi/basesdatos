$().ready(function() {

    $.ajax({
        type: "POST",
        url: "../API/followsAPI.php",
        dataType: 'json',
        data: {
            action: 3
        },
        success: function(data) {
            if (data["following"].length == 0){
              $("#totalFollowingDiv").html(0);
              $("#totalMalesDiv").html(0);
              $("#totalFemalesDiv").html(0);
              alert ("You are not following anyone yet!");
              return false; 
            }
            var html = "";
            var totalFollowers = data["totalFollowing"];
            var totalMales = data["totalMales"];
            var totalFemales = data["totalFemales"];
            $.each(data["following"], function(i, item){
                html += `<div class="col-md-3 col-xs-12 widget widget_tally_box">
                        <div class="x_panel fixed_height_300">
                          <div class="x_content">

                            <div class="flex">
                              <ul class="list-inline widget_profile_box">
                                <li>
                                  <a>
                                    <i class="fa fa-quote-left"></i>
                                  </a>
                                </li>
                                <li>
                                  <img src="`+item['picture']+`" alt="..." class="img-circle profile_img">
                                </li>
                                <li>
                                  <a>
                                    <i class="fa fa-quote-right"></i>
                                  </a>
                                </li>
                              </ul>
                            </div>
                            <h3 class="name"><a href="profile.php?userid=`+item["id"]+`">`+item["name"]+`</a></h3>
                            <div class="flex">
                              <ul class="list-inline count2">
                                <li>
                                  <h3>`+item["posts"]+`</h3>
                                  <span>Posts</span>
                                </li>
                                <li>
                                  <h3>`+item["followers"]+`</h3>
                                  <span>Followers</span>
                                </li>
                                <li>
                                  <h3>`+item["following"]+`</h3>
                                  <span>Following</span>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>`;
                      
            });
            $("#followingDiv").html(html);
            $("#totalFollowingDiv").html(totalFollowers);
            $("#totalMalesDiv").html(totalMales);
            $("#totalFemalesDiv").html(totalFemales);
        },
        error : function(data) {
            alert("Ha ocurrido un error." + JSON.stringify(data));
        }
    });
    
});
