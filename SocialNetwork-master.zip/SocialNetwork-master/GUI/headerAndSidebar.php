<?php $userId = $_COOKIE["id"] ?>
<body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a href="index.html" class="site_title"><i class="fa fa-globe"></i> <span>KIT</span></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <div class="profile">
              <div class="profile_pic">
                <img id="userImage1" src="" alt="..." class="img-circle profile_img">
              </div>
              <div class="profile_info">
                <span>Welcome,</span>
                <h2><?php echo $_COOKIE["name"]." ".$_COOKIE["secondName"]." ".$_COOKIE["lastName"]." ".$_COOKIE["secondLastName"] ?></h2>
              </div>
            </div>
            <!-- /menu profile quick info -->

            <br />

            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>General</h3>
                <ul class="nav side-menu">
                  <li><a href="index.php"><i class="fa fa-newspaper-o"></i> News Feed </a></li>
                  <li><a href="<?php echo "profile.php?=$userId";?>"><i class="fa fa-user"></i> Profile </a></li>
                  <li><a><i class="fa fa-users"></i> Follows <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="searchUsers.php">Search Users</a></li>
                      <li><a href="following.php">Following</a></li>
                      <li><a href="followers.php">Followers</a></li>
                    </ul>
                  </li>
                  <li><a href="inbox.php"><i class="fa fa-envelope"></i> Messages </a></li>
                </ul>
              </div>
                  

            </div>
            <!-- /sidebar menu -->
          </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>

              <ul class="nav navbar-nav navbar-right">
                <li class="">
                  <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <img id="userImage2" src="" alt=""><?php echo $_COOKIE["name"]." ".$_COOKIE["secondName"]." ".$_COOKIE["lastName"]." ".$_COOKIE["secondLastName"] ?>
                    <span class=" fa fa-angle-down"></span>
                  </a>
                  <ul class="dropdown-menu dropdown-usermenu pull-right">
                    <li><a href="<?php echo "profile.php?=$userId";?>"> Profile</a></li>
                    <li><a href="logout.php"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
                  </ul>
                </li>
              </ul>
            </nav>
          </div>
        </div>
        <!-- /top navigation -->

         <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>

        <!-- Script to load user image from mongoDB -->
        <script>
          var usrImg;

            if ( localStorage.getItem('userImg')) {
              usrImg = localStorage.getItem('userImg');
            }
            else {
              $.ajax({
                type: "POST",
                url: "../API/loginRegisterAPI.php",
                dataType: "json",
                async: false,
                data: {
                    action: 5,
                },
                success: function(data) {
                    usrImg = data["image"];
                },
                error : function(data) {
                    alert("Ha ocurrido un error." + JSON.stringify(data));
                }
              });
              localStorage.setItem('userImg',usrImg);
            }

            document.getElementById("userImage1").src=usrImg;
            document.getElementById("userImage2").src=usrImg;         
            
        </script>